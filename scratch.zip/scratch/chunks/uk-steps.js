(window["webpackJsonpGUI"] = window["webpackJsonpGUI"] || []).push([[13],{

/***/ 1587:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/bd2d7b2437946f1add631d2a55997b2f.gif";

/***/ }),

/***/ 1600:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/173e52e04ff6f2036add0558812948e6.gif";

/***/ }),

/***/ 2670:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9a2b4738446648557be6ffc033a6985e.gif";

/***/ }),

/***/ 2671:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e54636902d4b5c31f52aa582c0bac0f0.gif";

/***/ }),

/***/ 2672:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7a564b316d8659a75be31b3bde89ba34.gif";

/***/ }),

/***/ 2673:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/063892ef24eec57459ee932cec7e12e5.png";

/***/ }),

/***/ 2674:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/738a69d73a36644e21fc17a00b1bf3c8.png";

/***/ }),

/***/ 2675:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7a6a5c794d6fe77611613ddfdf905506.png";

/***/ }),

/***/ 2676:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3aec74140126f59247a5513ff0541125.png";

/***/ }),

/***/ 2677:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0d34c80e3919306cb722380e920cffac.png";

/***/ }),

/***/ 2678:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7e9fd4a23990a7a8f94c59c2671ecd62.png";

/***/ }),

/***/ 2679:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/85ba8d8493db6a87cd9b0010cfe09400.png";

/***/ }),

/***/ 2680:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/236f257f6b85917b5ba65dc9e4bb75df.png";

/***/ }),

/***/ 2681:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/93241021a13aa20da27f50e661016310.png";

/***/ }),

/***/ 2682:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a318b0c2bc41661e56b5dbb614ccd0f5.png";

/***/ }),

/***/ 2683:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ef9ad7d985162ed527aca819ad691267.png";

/***/ }),

/***/ 2684:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/69e164fac0cca66c053ecb31c9c2aa64.png";

/***/ }),

/***/ 2685:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/237bf42c437b2886b3e3097b078d6369.png";

/***/ }),

/***/ 2686:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d0705bad64076830636cdca02585a718.png";

/***/ }),

/***/ 2687:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0eab6235a1e9d8ff5beb1ecd80559ff5.png";

/***/ }),

/***/ 2688:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/edd3014da582ab3635dca5a05669a3f9.png";

/***/ }),

/***/ 2689:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d527a686da1975e039bf23e523bf1987.png";

/***/ }),

/***/ 2690:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/82be34b98c2cdc3b0a96e05484ccbc2b.png";

/***/ }),

/***/ 2691:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8075fd8604b9a5ba15f5ff83abf61357.png";

/***/ }),

/***/ 2692:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c6a87046d9f91f59c572d486f146a05f.png";

/***/ }),

/***/ 2693:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/80c7503180eff7feac884ffc8dc49dcf.png";

/***/ }),

/***/ 2694:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/53feb95d87a0cabdba0602df4b2c7abd.png";

/***/ }),

/***/ 2695:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d96fb43b5556759fae6433eecb5215cd.png";

/***/ }),

/***/ 2696:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/421e794b57e9d8a55f61dea8acbaf122.png";

/***/ }),

/***/ 2697:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/24609c50afb138ad00a7027f23265783.png";

/***/ }),

/***/ 2698:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b526b27033d326971504252c8a64799f.png";

/***/ }),

/***/ 2699:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f6156ddbd0164c7960a2d4c4f96f7342.png";

/***/ }),

/***/ 2700:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ff604ee848c4601eed6cdba13c6b461f.png";

/***/ }),

/***/ 2701:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2ccece2ca30002d265c673e1445b59c2.png";

/***/ }),

/***/ 2702:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c5849636045196cf49c2a738e7a002a5.png";

/***/ }),

/***/ 2703:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e28586864d5b4f6d48afbf833f8e0ec2.png";

/***/ }),

/***/ 2704:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7bd01b358fbe4512260286183d477685.png";

/***/ }),

/***/ 2705:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2b0b532fda25919c2ea7ff2129ae9271.png";

/***/ }),

/***/ 2706:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9c2e8fc66ddf257858ee277af88a7e45.png";

/***/ }),

/***/ 2707:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/64764c0e8dd11a31d0141c93ccb48a70.png";

/***/ }),

/***/ 2708:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/de056df8d895f6eb4e1992bc43c0c5e3.png";

/***/ }),

/***/ 2709:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/14ff0e9e964d43617c7298df4b888d10.png";

/***/ }),

/***/ 2710:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7da192543f5921c1d541937198c0afa9.gif";

/***/ }),

/***/ 2711:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8c07dca0e3f9f9c84b2fd70f4f1fbff9.png";

/***/ }),

/***/ 2712:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/adb3d064c06ba450a7c6da5ca21c7527.png";

/***/ }),

/***/ 2713:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/315a5675d1738c029b0f55817c249627.png";

/***/ }),

/***/ 2714:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0aed289656b9305b500b0e3efe867a5a.png";

/***/ }),

/***/ 2715:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/797c3df806ec50cd823c2e44d8671144.gif";

/***/ }),

/***/ 2716:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2737cd28da062447446bc93240e17270.png";

/***/ }),

/***/ 2717:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3cac0342b766442b1fbc630983c13950.png";

/***/ }),

/***/ 2718:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d1893578e9f1038e5b70b19465f7b58b.png";

/***/ }),

/***/ 2719:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/30a425e0a95db6048c84483c5cced06d.png";

/***/ }),

/***/ 2720:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a89ad1d0754a6ca305a1011dad503c96.png";

/***/ }),

/***/ 2721:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4bfa4db4f366febfd0a820b1655623dc.png";

/***/ }),

/***/ 2722:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b1efa4237175d3c78052aa209a7ded25.png";

/***/ }),

/***/ 2723:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/82b7f01c0e0f7966c9a2bb4c1bcc6298.png";

/***/ }),

/***/ 2724:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7fcbbbf879415d8bd7703b7560c08c28.png";

/***/ }),

/***/ 2725:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/06f3b7203e7424adb8a255f708d690b1.png";

/***/ }),

/***/ 2726:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d2c646eaa2c55f306468b28d7cedd554.png";

/***/ }),

/***/ 2727:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ef4b2066ab53d4f2b3e8fc62709f9014.png";

/***/ }),

/***/ 2728:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8bdce73195bf475057ff606ab3f6fffb.png";

/***/ }),

/***/ 2729:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/874e7dd6003137b73a9fbbdc7e34a27d.png";

/***/ }),

/***/ 2730:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0bf5e11621789f54a2ffbd7df4876ab2.png";

/***/ }),

/***/ 2731:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/340f5a3d6ae326f22b9707104adf6bb9.png";

/***/ }),

/***/ 2732:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/70a73e9b3fadba285a6d68db9a91cbb3.png";

/***/ }),

/***/ 2733:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6f8099642bca2cac1893f944dd47d330.png";

/***/ }),

/***/ 2734:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6522710dad0e4d577f33e159dc0207ef.png";

/***/ }),

/***/ 2735:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/40bdb123f50c303bc8471cf1b50e52a5.png";

/***/ }),

/***/ 2736:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/439cddb83c09b2be056ed9587a26ccf6.png";

/***/ }),

/***/ 2737:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e35418134f3ccf0992dae078ad213084.png";

/***/ }),

/***/ 2738:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/17a70f3f8ca6b0bb83834780b30d12d6.png";

/***/ }),

/***/ 2739:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/dbd143918003892a87ae09758a5243e4.png";

/***/ }),

/***/ 2740:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/58f20bb3e3aa666fb36a27ba5a0f746f.png";

/***/ }),

/***/ 2741:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/140a12db35626907175324712db456a7.gif";

/***/ }),

/***/ 2742:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2946d5a288356584985cf180be715a9a.png";

/***/ }),

/***/ 2743:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/96edc964e2954ef3166a77f87a6cc045.png";

/***/ }),

/***/ 2744:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/40d59a6d36dd479f7934cc35c3f6f795.png";

/***/ }),

/***/ 2745:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a23ddf472c2139e0c0361f74eb4da16e.png";

/***/ }),

/***/ 2746:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0b0662d4fa04471ec5b47ffd617bf5d3.png";

/***/ }),

/***/ 2747:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/30739a9d6fe024c005411f96dfbdfcd1.png";

/***/ }),

/***/ 2748:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7bb02f9c6e8c77206d09ff672bfaf9ec.png";

/***/ }),

/***/ 2749:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e71dba2ccaa69d866c3a022104e7bfad.png";

/***/ }),

/***/ 2750:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ebfac3f168323b5a72aa7562064b5e4c.png";

/***/ }),

/***/ 2751:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c73b30a718ff08201d4e75846d14d97c.png";

/***/ }),

/***/ 2752:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d78173077f3d3114ca769ae1b6671098.png";

/***/ }),

/***/ 2753:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e02b47da60ad2adf5b94b2633fe859c3.png";

/***/ }),

/***/ 2754:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/277cf108a773b6a4aa2c3b73c33d8227.png";

/***/ }),

/***/ 2755:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/10a6d6ad8a07826fa2cfa3f251619ba2.png";

/***/ }),

/***/ 2756:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ae64635916e1ddc8b0ac6bfd73c5cdf1.png";

/***/ }),

/***/ 2757:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/faef218a10693525eaa087f8c26fe2aa.png";

/***/ }),

/***/ 2758:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/91f2e12fe429965b5b219f289cf6aa31.png";

/***/ }),

/***/ 2759:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/721b68b3daef0cdc09dd1c06bab83334.png";

/***/ }),

/***/ 2760:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0e92716afebebbcf027802e341220ca0.png";

/***/ }),

/***/ 2761:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/642fb2f987bf8b54f176af13746c04cb.png";

/***/ }),

/***/ 2762:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ae564de8d4f7ca1a034180221227e91b.png";

/***/ }),

/***/ 2763:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/edf5571fc769a213bbbac59c1d03340f.png";

/***/ }),

/***/ 2764:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7d3dd7098c7f0f16ebd370cfeb1161e9.png";

/***/ }),

/***/ 2765:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6b4c7434da0f872e47f75f8b90b1c81d.png";

/***/ }),

/***/ 2766:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5ae26aa80ec6d5f2e99aa90ee1a3a5cd.png";

/***/ }),

/***/ 2767:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/181b5fac890880865e9131cde17e3d49.png";

/***/ }),

/***/ 2768:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8c6be33fc9a8eadffa880c9fe0ca6340.png";

/***/ }),

/***/ 2769:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d04305129eadebdbd60bbbcefd876177.png";

/***/ }),

/***/ 2770:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c019f6ed0fc028c1f003f1fb6eecaf8e.gif";

/***/ }),

/***/ 2771:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d3c86f1466ceed6f4ebd972e49e9c348.png";

/***/ }),

/***/ 2772:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/1c78a936bf640a0c11b21af1330d15df.png";

/***/ }),

/***/ 2886:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ukImages", function() { return ukImages; });
/* harmony import */ var _steps_intro_1_move_uk_gif__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2670);
/* harmony import */ var _steps_intro_1_move_uk_gif__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_1_move_uk_gif__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _steps_intro_2_say_uk_gif__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2671);
/* harmony import */ var _steps_intro_2_say_uk_gif__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_2_say_uk_gif__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _steps_intro_3_green_flag_uk_gif__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2672);
/* harmony import */ var _steps_intro_3_green_flag_uk_gif__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_3_green_flag_uk_gif__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _steps_speech_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1600);
/* harmony import */ var _steps_speech_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _steps_speech_say_something_uk_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2673);
/* harmony import */ var _steps_speech_say_something_uk_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_say_something_uk_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _steps_speech_set_voice_uk_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2674);
/* harmony import */ var _steps_speech_set_voice_uk_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_set_voice_uk_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _steps_speech_move_around_uk_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2675);
/* harmony import */ var _steps_speech_move_around_uk_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_move_around_uk_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(233);
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(386);
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _steps_speech_song_uk_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2676);
/* harmony import */ var _steps_speech_song_uk_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_song_uk_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _steps_speech_change_color_uk_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2677);
/* harmony import */ var _steps_speech_change_color_uk_png__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_change_color_uk_png__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _steps_speech_spin_uk_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2678);
/* harmony import */ var _steps_speech_spin_uk_png__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_spin_uk_png__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _steps_speech_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2679);
/* harmony import */ var _steps_speech_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(385);
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _steps_cn_say_uk_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2680);
/* harmony import */ var _steps_cn_say_uk_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_say_uk_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _steps_cn_glide_uk_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2681);
/* harmony import */ var _steps_cn_glide_uk_png__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_glide_uk_png__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(387);
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _steps_cn_collect_uk_png__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2682);
/* harmony import */ var _steps_cn_collect_uk_png__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_collect_uk_png__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1587);
/* harmony import */ var _steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _steps_cn_score_uk_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2683);
/* harmony import */ var _steps_cn_score_uk_png__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_score_uk_png__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _steps_cn_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(2684);
/* harmony import */ var _steps_cn_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(388);
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(389);
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _steps_name_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2685);
/* harmony import */ var _steps_name_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_steps_name_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(390);
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _steps_name_change_color_uk_png__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(2686);
/* harmony import */ var _steps_name_change_color_uk_png__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_steps_name_change_color_uk_png__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _steps_name_spin_uk_png__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(2687);
/* harmony import */ var _steps_name_spin_uk_png__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_steps_name_spin_uk_png__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _steps_name_grow_uk_png__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(2688);
/* harmony import */ var _steps_name_grow_uk_png__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_steps_name_grow_uk_png__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(391);
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _steps_music_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(2689);
/* harmony import */ var _steps_music_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_steps_music_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _steps_music_make_song_uk_png__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(2690);
/* harmony import */ var _steps_music_make_song_uk_png__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_song_uk_png__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _steps_music_make_beat_uk_png__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(2691);
/* harmony import */ var _steps_music_make_beat_uk_png__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beat_uk_png__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _steps_music_make_beatbox_uk_png__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(2692);
/* harmony import */ var _steps_music_make_beatbox_uk_png__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beatbox_uk_png__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(392);
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(393);
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var _steps_chase_game_right_left_uk_png__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(2693);
/* harmony import */ var _steps_chase_game_right_left_uk_png__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_right_left_uk_png__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _steps_chase_game_up_down_uk_png__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(2694);
/* harmony import */ var _steps_chase_game_up_down_uk_png__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_up_down_uk_png__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(394);
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var _steps_chase_game_move_randomly_uk_png__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(2695);
/* harmony import */ var _steps_chase_game_move_randomly_uk_png__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_move_randomly_uk_png__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var _steps_chase_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(2696);
/* harmony import */ var _steps_chase_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var _steps_chase_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(2697);
/* harmony import */ var _steps_chase_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(395);
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var _steps_pop_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(2698);
/* harmony import */ var _steps_pop_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var _steps_pop_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(2699);
/* harmony import */ var _steps_pop_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var _steps_pop_game_random_position_uk_png__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(2700);
/* harmony import */ var _steps_pop_game_random_position_uk_png__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_random_position_uk_png__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var _steps_pop_game_change_color_uk_png__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(2701);
/* harmony import */ var _steps_pop_game_change_color_uk_png__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_color_uk_png__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var _steps_pop_game_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(2702);
/* harmony import */ var _steps_pop_game_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(396);
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var _steps_animate_char_say_something_uk_png__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(2703);
/* harmony import */ var _steps_animate_char_say_something_uk_png__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_say_something_uk_png__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var _steps_animate_char_add_sound_uk_png__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(2704);
/* harmony import */ var _steps_animate_char_add_sound_uk_png__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_add_sound_uk_png__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var _steps_animate_char_talk_uk_png__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(2705);
/* harmony import */ var _steps_animate_char_talk_uk_png__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_talk_uk_png__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var _steps_animate_char_move_uk_png__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(2706);
/* harmony import */ var _steps_animate_char_move_uk_png__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_move_uk_png__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var _steps_animate_char_jump_uk_png__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(2707);
/* harmony import */ var _steps_animate_char_jump_uk_png__WEBPACK_IMPORTED_MODULE_52___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_jump_uk_png__WEBPACK_IMPORTED_MODULE_52__);
/* harmony import */ var _steps_animate_char_change_color_uk_png__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(2708);
/* harmony import */ var _steps_animate_char_change_color_uk_png__WEBPACK_IMPORTED_MODULE_53___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_change_color_uk_png__WEBPACK_IMPORTED_MODULE_53__);
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(397);
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__);
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(398);
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__);
/* harmony import */ var _steps_story_say_something_uk_png__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(2709);
/* harmony import */ var _steps_story_say_something_uk_png__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(_steps_story_say_something_uk_png__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(399);
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var _steps_story_flip_uk_gif__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(2710);
/* harmony import */ var _steps_story_flip_uk_gif__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(_steps_story_flip_uk_gif__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var _steps_story_conversation_uk_png__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(2711);
/* harmony import */ var _steps_story_conversation_uk_png__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(_steps_story_conversation_uk_png__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(400);
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__);
/* harmony import */ var _steps_story_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(2712);
/* harmony import */ var _steps_story_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_61___default = /*#__PURE__*/__webpack_require__.n(_steps_story_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_61__);
/* harmony import */ var _steps_story_hide_character_uk_png__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(2713);
/* harmony import */ var _steps_story_hide_character_uk_png__WEBPACK_IMPORTED_MODULE_62___default = /*#__PURE__*/__webpack_require__.n(_steps_story_hide_character_uk_png__WEBPACK_IMPORTED_MODULE_62__);
/* harmony import */ var _steps_story_show_character_uk_png__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(2714);
/* harmony import */ var _steps_story_show_character_uk_png__WEBPACK_IMPORTED_MODULE_63___default = /*#__PURE__*/__webpack_require__.n(_steps_story_show_character_uk_png__WEBPACK_IMPORTED_MODULE_63__);
/* harmony import */ var _steps_video_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(2715);
/* harmony import */ var _steps_video_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_64___default = /*#__PURE__*/__webpack_require__.n(_steps_video_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_64__);
/* harmony import */ var _steps_video_pet_uk_png__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(2716);
/* harmony import */ var _steps_video_pet_uk_png__WEBPACK_IMPORTED_MODULE_65___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pet_uk_png__WEBPACK_IMPORTED_MODULE_65__);
/* harmony import */ var _steps_video_animate_uk_png__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(2717);
/* harmony import */ var _steps_video_animate_uk_png__WEBPACK_IMPORTED_MODULE_66___default = /*#__PURE__*/__webpack_require__.n(_steps_video_animate_uk_png__WEBPACK_IMPORTED_MODULE_66__);
/* harmony import */ var _steps_video_pop_uk_png__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(2718);
/* harmony import */ var _steps_video_pop_uk_png__WEBPACK_IMPORTED_MODULE_67___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pop_uk_png__WEBPACK_IMPORTED_MODULE_67__);
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(401);
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__);
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(402);
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__);
/* harmony import */ var _steps_fly_say_something_uk_png__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(2719);
/* harmony import */ var _steps_fly_say_something_uk_png__WEBPACK_IMPORTED_MODULE_70___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_say_something_uk_png__WEBPACK_IMPORTED_MODULE_70__);
/* harmony import */ var _steps_fly_make_interactive_uk_png__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(2720);
/* harmony import */ var _steps_fly_make_interactive_uk_png__WEBPACK_IMPORTED_MODULE_71___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_make_interactive_uk_png__WEBPACK_IMPORTED_MODULE_71__);
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(403);
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__);
/* harmony import */ var _steps_fly_flying_heart_uk_png__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(2721);
/* harmony import */ var _steps_fly_flying_heart_uk_png__WEBPACK_IMPORTED_MODULE_73___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_flying_heart_uk_png__WEBPACK_IMPORTED_MODULE_73__);
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(404);
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__);
/* harmony import */ var _steps_fly_keep_score_uk_png__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(2722);
/* harmony import */ var _steps_fly_keep_score_uk_png__WEBPACK_IMPORTED_MODULE_75___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_keep_score_uk_png__WEBPACK_IMPORTED_MODULE_75__);
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(405);
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__);
/* harmony import */ var _steps_fly_move_scenery_uk_png__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(2723);
/* harmony import */ var _steps_fly_move_scenery_uk_png__WEBPACK_IMPORTED_MODULE_77___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_move_scenery_uk_png__WEBPACK_IMPORTED_MODULE_77__);
/* harmony import */ var _steps_fly_switch_costume_uk_png__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(2724);
/* harmony import */ var _steps_fly_switch_costume_uk_png__WEBPACK_IMPORTED_MODULE_78___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_switch_costume_uk_png__WEBPACK_IMPORTED_MODULE_78__);
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(406);
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__);
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__ = __webpack_require__(407);
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__);
/* harmony import */ var _steps_pong_bounce_around_uk_png__WEBPACK_IMPORTED_MODULE_81__ = __webpack_require__(2725);
/* harmony import */ var _steps_pong_bounce_around_uk_png__WEBPACK_IMPORTED_MODULE_81___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_bounce_around_uk_png__WEBPACK_IMPORTED_MODULE_81__);
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__ = __webpack_require__(408);
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__);
/* harmony import */ var _steps_pong_move_the_paddle_uk_png__WEBPACK_IMPORTED_MODULE_83__ = __webpack_require__(2726);
/* harmony import */ var _steps_pong_move_the_paddle_uk_png__WEBPACK_IMPORTED_MODULE_83___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_move_the_paddle_uk_png__WEBPACK_IMPORTED_MODULE_83__);
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__ = __webpack_require__(409);
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__);
/* harmony import */ var _steps_pong_add_code_to_ball_uk_png__WEBPACK_IMPORTED_MODULE_85__ = __webpack_require__(2727);
/* harmony import */ var _steps_pong_add_code_to_ball_uk_png__WEBPACK_IMPORTED_MODULE_85___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_code_to_ball_uk_png__WEBPACK_IMPORTED_MODULE_85__);
/* harmony import */ var _steps_pong_choose_score_uk_png__WEBPACK_IMPORTED_MODULE_86__ = __webpack_require__(2728);
/* harmony import */ var _steps_pong_choose_score_uk_png__WEBPACK_IMPORTED_MODULE_86___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_choose_score_uk_png__WEBPACK_IMPORTED_MODULE_86__);
/* harmony import */ var _steps_pong_insert_change_score_uk_png__WEBPACK_IMPORTED_MODULE_87__ = __webpack_require__(2729);
/* harmony import */ var _steps_pong_insert_change_score_uk_png__WEBPACK_IMPORTED_MODULE_87___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_insert_change_score_uk_png__WEBPACK_IMPORTED_MODULE_87__);
/* harmony import */ var _steps_pong_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_88__ = __webpack_require__(2730);
/* harmony import */ var _steps_pong_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_88___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_88__);
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__ = __webpack_require__(410);
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__);
/* harmony import */ var _steps_pong_game_over_uk_png__WEBPACK_IMPORTED_MODULE_90__ = __webpack_require__(2731);
/* harmony import */ var _steps_pong_game_over_uk_png__WEBPACK_IMPORTED_MODULE_90___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_game_over_uk_png__WEBPACK_IMPORTED_MODULE_90__);
/* harmony import */ var _steps_imagine_type_what_you_want_uk_png__WEBPACK_IMPORTED_MODULE_91__ = __webpack_require__(2732);
/* harmony import */ var _steps_imagine_type_what_you_want_uk_png__WEBPACK_IMPORTED_MODULE_91___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_type_what_you_want_uk_png__WEBPACK_IMPORTED_MODULE_91__);
/* harmony import */ var _steps_imagine_click_green_flag_uk_png__WEBPACK_IMPORTED_MODULE_92__ = __webpack_require__(2733);
/* harmony import */ var _steps_imagine_click_green_flag_uk_png__WEBPACK_IMPORTED_MODULE_92___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_click_green_flag_uk_png__WEBPACK_IMPORTED_MODULE_92__);
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__ = __webpack_require__(411);
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__);
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__ = __webpack_require__(412);
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__);
/* harmony import */ var _steps_imagine_fly_around_uk_png__WEBPACK_IMPORTED_MODULE_95__ = __webpack_require__(2734);
/* harmony import */ var _steps_imagine_fly_around_uk_png__WEBPACK_IMPORTED_MODULE_95___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_fly_around_uk_png__WEBPACK_IMPORTED_MODULE_95__);
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__ = __webpack_require__(413);
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__);
/* harmony import */ var _steps_imagine_left_right_uk_png__WEBPACK_IMPORTED_MODULE_97__ = __webpack_require__(2735);
/* harmony import */ var _steps_imagine_left_right_uk_png__WEBPACK_IMPORTED_MODULE_97___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_left_right_uk_png__WEBPACK_IMPORTED_MODULE_97__);
/* harmony import */ var _steps_imagine_up_down_uk_png__WEBPACK_IMPORTED_MODULE_98__ = __webpack_require__(2736);
/* harmony import */ var _steps_imagine_up_down_uk_png__WEBPACK_IMPORTED_MODULE_98___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_up_down_uk_png__WEBPACK_IMPORTED_MODULE_98__);
/* harmony import */ var _steps_imagine_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_99__ = __webpack_require__(2737);
/* harmony import */ var _steps_imagine_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_99___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_99__);
/* harmony import */ var _steps_imagine_glide_to_point_uk_png__WEBPACK_IMPORTED_MODULE_100__ = __webpack_require__(2738);
/* harmony import */ var _steps_imagine_glide_to_point_uk_png__WEBPACK_IMPORTED_MODULE_100___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_glide_to_point_uk_png__WEBPACK_IMPORTED_MODULE_100__);
/* harmony import */ var _steps_imagine_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_101__ = __webpack_require__(2739);
/* harmony import */ var _steps_imagine_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_101___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_101__);
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__ = __webpack_require__(414);
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__);
/* harmony import */ var _steps_imagine_switch_backdrops_uk_png__WEBPACK_IMPORTED_MODULE_103__ = __webpack_require__(2740);
/* harmony import */ var _steps_imagine_switch_backdrops_uk_png__WEBPACK_IMPORTED_MODULE_103___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_switch_backdrops_uk_png__WEBPACK_IMPORTED_MODULE_103__);
/* harmony import */ var _steps_imagine_record_a_sound_uk_gif__WEBPACK_IMPORTED_MODULE_104__ = __webpack_require__(2741);
/* harmony import */ var _steps_imagine_record_a_sound_uk_gif__WEBPACK_IMPORTED_MODULE_104___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_record_a_sound_uk_gif__WEBPACK_IMPORTED_MODULE_104__);
/* harmony import */ var _steps_imagine_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_105__ = __webpack_require__(2742);
/* harmony import */ var _steps_imagine_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_105___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_105__);
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__ = __webpack_require__(415);
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default = /*#__PURE__*/__webpack_require__.n(_steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__);
/* harmony import */ var _steps_add_effects_uk_png__WEBPACK_IMPORTED_MODULE_107__ = __webpack_require__(2743);
/* harmony import */ var _steps_add_effects_uk_png__WEBPACK_IMPORTED_MODULE_107___default = /*#__PURE__*/__webpack_require__.n(_steps_add_effects_uk_png__WEBPACK_IMPORTED_MODULE_107__);
/* harmony import */ var _steps_hide_show_uk_png__WEBPACK_IMPORTED_MODULE_108__ = __webpack_require__(2744);
/* harmony import */ var _steps_hide_show_uk_png__WEBPACK_IMPORTED_MODULE_108___default = /*#__PURE__*/__webpack_require__.n(_steps_hide_show_uk_png__WEBPACK_IMPORTED_MODULE_108__);
/* harmony import */ var _steps_switch_costumes_uk_png__WEBPACK_IMPORTED_MODULE_109__ = __webpack_require__(2745);
/* harmony import */ var _steps_switch_costumes_uk_png__WEBPACK_IMPORTED_MODULE_109___default = /*#__PURE__*/__webpack_require__.n(_steps_switch_costumes_uk_png__WEBPACK_IMPORTED_MODULE_109__);
/* harmony import */ var _steps_change_size_uk_png__WEBPACK_IMPORTED_MODULE_110__ = __webpack_require__(2746);
/* harmony import */ var _steps_change_size_uk_png__WEBPACK_IMPORTED_MODULE_110___default = /*#__PURE__*/__webpack_require__.n(_steps_change_size_uk_png__WEBPACK_IMPORTED_MODULE_110__);
/* harmony import */ var _steps_spin_turn_uk_png__WEBPACK_IMPORTED_MODULE_111__ = __webpack_require__(2747);
/* harmony import */ var _steps_spin_turn_uk_png__WEBPACK_IMPORTED_MODULE_111___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_turn_uk_png__WEBPACK_IMPORTED_MODULE_111__);
/* harmony import */ var _steps_spin_point_in_direction_uk_png__WEBPACK_IMPORTED_MODULE_112__ = __webpack_require__(2748);
/* harmony import */ var _steps_spin_point_in_direction_uk_png__WEBPACK_IMPORTED_MODULE_112___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_point_in_direction_uk_png__WEBPACK_IMPORTED_MODULE_112__);
/* harmony import */ var _steps_record_a_sound_sounds_tab_uk_png__WEBPACK_IMPORTED_MODULE_113__ = __webpack_require__(2749);
/* harmony import */ var _steps_record_a_sound_sounds_tab_uk_png__WEBPACK_IMPORTED_MODULE_113___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_sounds_tab_uk_png__WEBPACK_IMPORTED_MODULE_113__);
/* harmony import */ var _steps_record_a_sound_click_record_uk_png__WEBPACK_IMPORTED_MODULE_114__ = __webpack_require__(2750);
/* harmony import */ var _steps_record_a_sound_click_record_uk_png__WEBPACK_IMPORTED_MODULE_114___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_click_record_uk_png__WEBPACK_IMPORTED_MODULE_114__);
/* harmony import */ var _steps_record_a_sound_press_record_button_uk_png__WEBPACK_IMPORTED_MODULE_115__ = __webpack_require__(2751);
/* harmony import */ var _steps_record_a_sound_press_record_button_uk_png__WEBPACK_IMPORTED_MODULE_115___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_press_record_button_uk_png__WEBPACK_IMPORTED_MODULE_115__);
/* harmony import */ var _steps_record_a_sound_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_116__ = __webpack_require__(2752);
/* harmony import */ var _steps_record_a_sound_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_116___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_116__);
/* harmony import */ var _steps_record_a_sound_play_your_sound_uk_png__WEBPACK_IMPORTED_MODULE_117__ = __webpack_require__(2753);
/* harmony import */ var _steps_record_a_sound_play_your_sound_uk_png__WEBPACK_IMPORTED_MODULE_117___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_play_your_sound_uk_png__WEBPACK_IMPORTED_MODULE_117__);
/* harmony import */ var _steps_move_arrow_keys_left_right_uk_png__WEBPACK_IMPORTED_MODULE_118__ = __webpack_require__(2754);
/* harmony import */ var _steps_move_arrow_keys_left_right_uk_png__WEBPACK_IMPORTED_MODULE_118___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_left_right_uk_png__WEBPACK_IMPORTED_MODULE_118__);
/* harmony import */ var _steps_move_arrow_keys_up_down_uk_png__WEBPACK_IMPORTED_MODULE_119__ = __webpack_require__(2755);
/* harmony import */ var _steps_move_arrow_keys_up_down_uk_png__WEBPACK_IMPORTED_MODULE_119___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_up_down_uk_png__WEBPACK_IMPORTED_MODULE_119__);
/* harmony import */ var _steps_glide_around_back_and_forth_uk_png__WEBPACK_IMPORTED_MODULE_120__ = __webpack_require__(2756);
/* harmony import */ var _steps_glide_around_back_and_forth_uk_png__WEBPACK_IMPORTED_MODULE_120___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_back_and_forth_uk_png__WEBPACK_IMPORTED_MODULE_120__);
/* harmony import */ var _steps_glide_around_point_uk_png__WEBPACK_IMPORTED_MODULE_121__ = __webpack_require__(2757);
/* harmony import */ var _steps_glide_around_point_uk_png__WEBPACK_IMPORTED_MODULE_121___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_point_uk_png__WEBPACK_IMPORTED_MODULE_121__);
/* harmony import */ var _steps_code_cartoon_01_say_something_uk_png__WEBPACK_IMPORTED_MODULE_122__ = __webpack_require__(2758);
/* harmony import */ var _steps_code_cartoon_01_say_something_uk_png__WEBPACK_IMPORTED_MODULE_122___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_01_say_something_uk_png__WEBPACK_IMPORTED_MODULE_122__);
/* harmony import */ var _steps_code_cartoon_02_animate_uk_png__WEBPACK_IMPORTED_MODULE_123__ = __webpack_require__(2759);
/* harmony import */ var _steps_code_cartoon_02_animate_uk_png__WEBPACK_IMPORTED_MODULE_123___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_02_animate_uk_png__WEBPACK_IMPORTED_MODULE_123__);
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__ = __webpack_require__(416);
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__);
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_uk_png__WEBPACK_IMPORTED_MODULE_125__ = __webpack_require__(2760);
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_uk_png__WEBPACK_IMPORTED_MODULE_125___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_04_use_minus_sign_uk_png__WEBPACK_IMPORTED_MODULE_125__);
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_126__ = __webpack_require__(2761);
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_126___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_05_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_126__);
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__ = __webpack_require__(417);
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__);
/* harmony import */ var _steps_code_cartoon_07_jump_uk_png__WEBPACK_IMPORTED_MODULE_128__ = __webpack_require__(2762);
/* harmony import */ var _steps_code_cartoon_07_jump_uk_png__WEBPACK_IMPORTED_MODULE_128___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_07_jump_uk_png__WEBPACK_IMPORTED_MODULE_128__);
/* harmony import */ var _steps_code_cartoon_08_change_scenes_uk_png__WEBPACK_IMPORTED_MODULE_129__ = __webpack_require__(2763);
/* harmony import */ var _steps_code_cartoon_08_change_scenes_uk_png__WEBPACK_IMPORTED_MODULE_129___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_08_change_scenes_uk_png__WEBPACK_IMPORTED_MODULE_129__);
/* harmony import */ var _steps_code_cartoon_09_glide_around_uk_png__WEBPACK_IMPORTED_MODULE_130__ = __webpack_require__(2764);
/* harmony import */ var _steps_code_cartoon_09_glide_around_uk_png__WEBPACK_IMPORTED_MODULE_130___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_09_glide_around_uk_png__WEBPACK_IMPORTED_MODULE_130__);
/* harmony import */ var _steps_code_cartoon_10_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_131__ = __webpack_require__(2765);
/* harmony import */ var _steps_code_cartoon_10_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_131___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_10_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_131__);
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__ = __webpack_require__(418);
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__);
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__ = __webpack_require__(419);
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__);
/* harmony import */ var _steps_talking_3_say_something_uk_png__WEBPACK_IMPORTED_MODULE_134__ = __webpack_require__(2766);
/* harmony import */ var _steps_talking_3_say_something_uk_png__WEBPACK_IMPORTED_MODULE_134___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_3_say_something_uk_png__WEBPACK_IMPORTED_MODULE_134__);
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__ = __webpack_require__(420);
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__);
/* harmony import */ var _steps_talking_5_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_136__ = __webpack_require__(2767);
/* harmony import */ var _steps_talking_5_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_136___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_5_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_136__);
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__ = __webpack_require__(421);
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__);
/* harmony import */ var _steps_talking_7_move_around_uk_png__WEBPACK_IMPORTED_MODULE_138__ = __webpack_require__(2768);
/* harmony import */ var _steps_talking_7_move_around_uk_png__WEBPACK_IMPORTED_MODULE_138___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_7_move_around_uk_png__WEBPACK_IMPORTED_MODULE_138__);
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__ = __webpack_require__(422);
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__);
/* harmony import */ var _steps_talking_9_animate_uk_png__WEBPACK_IMPORTED_MODULE_140__ = __webpack_require__(2769);
/* harmony import */ var _steps_talking_9_animate_uk_png__WEBPACK_IMPORTED_MODULE_140___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_9_animate_uk_png__WEBPACK_IMPORTED_MODULE_140__);
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__ = __webpack_require__(423);
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__);
/* harmony import */ var _steps_talking_11_choose_sound_uk_gif__WEBPACK_IMPORTED_MODULE_142__ = __webpack_require__(2770);
/* harmony import */ var _steps_talking_11_choose_sound_uk_gif__WEBPACK_IMPORTED_MODULE_142___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_11_choose_sound_uk_gif__WEBPACK_IMPORTED_MODULE_142__);
/* harmony import */ var _steps_talking_12_dance_moves_uk_png__WEBPACK_IMPORTED_MODULE_143__ = __webpack_require__(2771);
/* harmony import */ var _steps_talking_12_dance_moves_uk_png__WEBPACK_IMPORTED_MODULE_143___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_12_dance_moves_uk_png__WEBPACK_IMPORTED_MODULE_143__);
/* harmony import */ var _steps_talking_13_ask_and_answer_uk_png__WEBPACK_IMPORTED_MODULE_144__ = __webpack_require__(2772);
/* harmony import */ var _steps_talking_13_ask_and_answer_uk_png__WEBPACK_IMPORTED_MODULE_144___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_13_ask_and_answer_uk_png__WEBPACK_IMPORTED_MODULE_144__);
// Intro


 // Text to Speech










 // Cartoon Network








 // Add sprite

 // Animate a name






 // Make Music





 // Chase-Game









 // Clicker-Game (Pop Game)







 // Animate A Character








 // Tell A Story










 // Video Sensing




 // Make it Fly












 // Pong













 // Imagine a World















 // Add a Backdrop

 // Add Effects

 // Hide and Show

 // Switch Costumes

 // Change Size

 // Spin


 // Record a Sound





 // Use Arrow Keys


 // Glide Around


 // Code a Cartoon











 // Talking Tales














var ukImages = {
  // Intro
  introMove: _steps_intro_1_move_uk_gif__WEBPACK_IMPORTED_MODULE_0___default.a,
  introSay: _steps_intro_2_say_uk_gif__WEBPACK_IMPORTED_MODULE_1___default.a,
  introGreenFlag: _steps_intro_3_green_flag_uk_gif__WEBPACK_IMPORTED_MODULE_2___default.a,
  // Text to Speech
  speechAddExtension: _steps_speech_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  speechSaySomething: _steps_speech_say_something_uk_png__WEBPACK_IMPORTED_MODULE_4___default.a,
  speechSetVoice: _steps_speech_set_voice_uk_png__WEBPACK_IMPORTED_MODULE_5___default.a,
  speechMoveAround: _steps_speech_move_around_uk_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  speechAddBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  speechAddSprite: _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default.a,
  speechSong: _steps_speech_song_uk_png__WEBPACK_IMPORTED_MODULE_9___default.a,
  speechChangeColor: _steps_speech_change_color_uk_png__WEBPACK_IMPORTED_MODULE_10___default.a,
  speechSpin: _steps_speech_spin_uk_png__WEBPACK_IMPORTED_MODULE_11___default.a,
  speechGrowShrink: _steps_speech_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_12___default.a,
  // Cartoon Network
  cnShowCharacter: _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default.a,
  cnSay: _steps_cn_say_uk_png__WEBPACK_IMPORTED_MODULE_14___default.a,
  cnGlide: _steps_cn_glide_uk_png__WEBPACK_IMPORTED_MODULE_15___default.a,
  cnPickSprite: _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default.a,
  cnCollect: _steps_cn_collect_uk_png__WEBPACK_IMPORTED_MODULE_17___default.a,
  cnVariable: _steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  cnScore: _steps_cn_score_uk_png__WEBPACK_IMPORTED_MODULE_19___default.a,
  cnBackdrop: _steps_cn_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_20___default.a,
  // Add sprite
  addSprite: _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default.a,
  // Animate a name
  namePickLetter: _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default.a,
  namePlaySound: _steps_name_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_23___default.a,
  namePickLetter2: _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default.a,
  nameChangeColor: _steps_name_change_color_uk_png__WEBPACK_IMPORTED_MODULE_25___default.a,
  nameSpin: _steps_name_spin_uk_png__WEBPACK_IMPORTED_MODULE_26___default.a,
  nameGrow: _steps_name_grow_uk_png__WEBPACK_IMPORTED_MODULE_27___default.a,
  // Make-Music
  musicPickInstrument: _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default.a,
  musicPlaySound: _steps_music_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_29___default.a,
  musicMakeSong: _steps_music_make_song_uk_png__WEBPACK_IMPORTED_MODULE_30___default.a,
  musicMakeBeat: _steps_music_make_beat_uk_png__WEBPACK_IMPORTED_MODULE_31___default.a,
  musicMakeBeatbox: _steps_music_make_beatbox_uk_png__WEBPACK_IMPORTED_MODULE_32___default.a,
  // Chase-Game
  chaseGameAddBackdrop: _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default.a,
  chaseGameAddSprite1: _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default.a,
  chaseGameRightLeft: _steps_chase_game_right_left_uk_png__WEBPACK_IMPORTED_MODULE_35___default.a,
  chaseGameUpDown: _steps_chase_game_up_down_uk_png__WEBPACK_IMPORTED_MODULE_36___default.a,
  chaseGameAddSprite2: _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default.a,
  chaseGameMoveRandomly: _steps_chase_game_move_randomly_uk_png__WEBPACK_IMPORTED_MODULE_38___default.a,
  chaseGamePlaySound: _steps_chase_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_39___default.a,
  chaseGameAddVariable: _steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  chaseGameChangeScore: _steps_chase_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_40___default.a,
  // Make-A-Pop/Clicker Game
  popGamePickSprite: _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default.a,
  popGamePlaySound: _steps_pop_game_play_sound_uk_png__WEBPACK_IMPORTED_MODULE_42___default.a,
  popGameAddScore: _steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  popGameChangeScore: _steps_pop_game_change_score_uk_png__WEBPACK_IMPORTED_MODULE_43___default.a,
  popGameRandomPosition: _steps_pop_game_random_position_uk_png__WEBPACK_IMPORTED_MODULE_44___default.a,
  popGameChangeColor: _steps_pop_game_change_color_uk_png__WEBPACK_IMPORTED_MODULE_45___default.a,
  popGameResetScore: _steps_pop_game_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_46___default.a,
  // Animate A Character
  animateCharPickBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  animateCharPickSprite: _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default.a,
  animateCharSaySomething: _steps_animate_char_say_something_uk_png__WEBPACK_IMPORTED_MODULE_48___default.a,
  animateCharAddSound: _steps_animate_char_add_sound_uk_png__WEBPACK_IMPORTED_MODULE_49___default.a,
  animateCharTalk: _steps_animate_char_talk_uk_png__WEBPACK_IMPORTED_MODULE_50___default.a,
  animateCharMove: _steps_animate_char_move_uk_png__WEBPACK_IMPORTED_MODULE_51___default.a,
  animateCharJump: _steps_animate_char_jump_uk_png__WEBPACK_IMPORTED_MODULE_52___default.a,
  animateCharChangeColor: _steps_animate_char_change_color_uk_png__WEBPACK_IMPORTED_MODULE_53___default.a,
  // Tell A Story
  storyPickBackdrop: _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default.a,
  storyPickSprite: _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default.a,
  storySaySomething: _steps_story_say_something_uk_png__WEBPACK_IMPORTED_MODULE_56___default.a,
  storyPickSprite2: _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default.a,
  storyFlip: _steps_story_flip_uk_gif__WEBPACK_IMPORTED_MODULE_58___default.a,
  storyConversation: _steps_story_conversation_uk_png__WEBPACK_IMPORTED_MODULE_59___default.a,
  storyPickBackdrop2: _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default.a,
  storySwitchBackdrop: _steps_story_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_61___default.a,
  storyHideCharacter: _steps_story_hide_character_uk_png__WEBPACK_IMPORTED_MODULE_62___default.a,
  storyShowCharacter: _steps_story_show_character_uk_png__WEBPACK_IMPORTED_MODULE_63___default.a,
  // Video Sensing
  videoAddExtension: _steps_video_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_64___default.a,
  videoPet: _steps_video_pet_uk_png__WEBPACK_IMPORTED_MODULE_65___default.a,
  videoAnimate: _steps_video_animate_uk_png__WEBPACK_IMPORTED_MODULE_66___default.a,
  videoPop: _steps_video_pop_uk_png__WEBPACK_IMPORTED_MODULE_67___default.a,
  // Make it Fly
  flyChooseBackdrop: _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default.a,
  flyChooseCharacter: _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default.a,
  flySaySomething: _steps_fly_say_something_uk_png__WEBPACK_IMPORTED_MODULE_70___default.a,
  flyMoveArrows: _steps_fly_make_interactive_uk_png__WEBPACK_IMPORTED_MODULE_71___default.a,
  flyChooseObject: _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default.a,
  flyFlyingObject: _steps_fly_flying_heart_uk_png__WEBPACK_IMPORTED_MODULE_73___default.a,
  flySelectFlyingSprite: _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default.a,
  flyAddScore: _steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  flyKeepScore: _steps_fly_keep_score_uk_png__WEBPACK_IMPORTED_MODULE_75___default.a,
  flyAddScenery: _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default.a,
  flyMoveScenery: _steps_fly_move_scenery_uk_png__WEBPACK_IMPORTED_MODULE_77___default.a,
  flySwitchLooks: _steps_fly_switch_costume_uk_png__WEBPACK_IMPORTED_MODULE_78___default.a,
  // Pong
  pongAddBackdrop: _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default.a,
  pongAddBallSprite: _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default.a,
  pongBounceAround: _steps_pong_bounce_around_uk_png__WEBPACK_IMPORTED_MODULE_81___default.a,
  pongAddPaddle: _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default.a,
  pongMoveThePaddle: _steps_pong_move_the_paddle_uk_png__WEBPACK_IMPORTED_MODULE_83___default.a,
  pongSelectBallSprite: _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default.a,
  pongAddMoreCodeToBall: _steps_pong_add_code_to_ball_uk_png__WEBPACK_IMPORTED_MODULE_85___default.a,
  pongAddAScore: _steps_add_variable_uk_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  pongChooseScoreFromMenu: _steps_pong_choose_score_uk_png__WEBPACK_IMPORTED_MODULE_86___default.a,
  pongInsertChangeScoreBlock: _steps_pong_insert_change_score_uk_png__WEBPACK_IMPORTED_MODULE_87___default.a,
  pongResetScore: _steps_pong_reset_score_uk_png__WEBPACK_IMPORTED_MODULE_88___default.a,
  pongAddLineSprite: _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default.a,
  pongGameOver: _steps_pong_game_over_uk_png__WEBPACK_IMPORTED_MODULE_90___default.a,
  // Imagine a World
  imagineTypeWhatYouWant: _steps_imagine_type_what_you_want_uk_png__WEBPACK_IMPORTED_MODULE_91___default.a,
  imagineClickGreenFlag: _steps_imagine_click_green_flag_uk_png__WEBPACK_IMPORTED_MODULE_92___default.a,
  imagineChooseBackdrop: _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default.a,
  imagineChooseSprite: _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default.a,
  imagineFlyAround: _steps_imagine_fly_around_uk_png__WEBPACK_IMPORTED_MODULE_95___default.a,
  imagineChooseAnotherSprite: _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default.a,
  imagineLeftRight: _steps_imagine_left_right_uk_png__WEBPACK_IMPORTED_MODULE_97___default.a,
  imagineUpDown: _steps_imagine_up_down_uk_png__WEBPACK_IMPORTED_MODULE_98___default.a,
  imagineChangeCostumes: _steps_imagine_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_99___default.a,
  imagineGlideToPoint: _steps_imagine_glide_to_point_uk_png__WEBPACK_IMPORTED_MODULE_100___default.a,
  imagineGrowShrink: _steps_imagine_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_101___default.a,
  imagineChooseAnotherBackdrop: _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default.a,
  imagineSwitchBackdrops: _steps_imagine_switch_backdrops_uk_png__WEBPACK_IMPORTED_MODULE_103___default.a,
  imagineRecordASound: _steps_imagine_record_a_sound_uk_gif__WEBPACK_IMPORTED_MODULE_104___default.a,
  imagineChooseSound: _steps_imagine_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_105___default.a,
  // Add a Backdrop
  addBackdrop: _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default.a,
  // Add Effects
  addEffects: _steps_add_effects_uk_png__WEBPACK_IMPORTED_MODULE_107___default.a,
  // Hide and Show
  hideAndShow: _steps_hide_show_uk_png__WEBPACK_IMPORTED_MODULE_108___default.a,
  // Switch Costumes
  switchCostumes: _steps_switch_costumes_uk_png__WEBPACK_IMPORTED_MODULE_109___default.a,
  // Change Size
  changeSize: _steps_change_size_uk_png__WEBPACK_IMPORTED_MODULE_110___default.a,
  // Spin
  spinTurn: _steps_spin_turn_uk_png__WEBPACK_IMPORTED_MODULE_111___default.a,
  spinPointInDirection: _steps_spin_point_in_direction_uk_png__WEBPACK_IMPORTED_MODULE_112___default.a,
  // Record a Sound
  recordASoundSoundsTab: _steps_record_a_sound_sounds_tab_uk_png__WEBPACK_IMPORTED_MODULE_113___default.a,
  recordASoundClickRecord: _steps_record_a_sound_click_record_uk_png__WEBPACK_IMPORTED_MODULE_114___default.a,
  recordASoundPressRecordButton: _steps_record_a_sound_press_record_button_uk_png__WEBPACK_IMPORTED_MODULE_115___default.a,
  recordASoundChooseSound: _steps_record_a_sound_choose_sound_uk_png__WEBPACK_IMPORTED_MODULE_116___default.a,
  recordASoundPlayYourSound: _steps_record_a_sound_play_your_sound_uk_png__WEBPACK_IMPORTED_MODULE_117___default.a,
  // Use Arrow Keys
  moveArrowKeysLeftRight: _steps_move_arrow_keys_left_right_uk_png__WEBPACK_IMPORTED_MODULE_118___default.a,
  moveArrowKeysUpDown: _steps_move_arrow_keys_up_down_uk_png__WEBPACK_IMPORTED_MODULE_119___default.a,
  // Glide Around
  glideAroundBackAndForth: _steps_glide_around_back_and_forth_uk_png__WEBPACK_IMPORTED_MODULE_120___default.a,
  glideAroundPoint: _steps_glide_around_point_uk_png__WEBPACK_IMPORTED_MODULE_121___default.a,
  // Code a Cartoon
  codeCartoonSaySomething: _steps_code_cartoon_01_say_something_uk_png__WEBPACK_IMPORTED_MODULE_122___default.a,
  codeCartoonAnimate: _steps_code_cartoon_02_animate_uk_png__WEBPACK_IMPORTED_MODULE_123___default.a,
  codeCartoonSelectDifferentCharacter: _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default.a,
  codeCartoonUseMinusSign: _steps_code_cartoon_04_use_minus_sign_uk_png__WEBPACK_IMPORTED_MODULE_125___default.a,
  codeCartoonGrowShrink: _steps_code_cartoon_05_grow_shrink_uk_png__WEBPACK_IMPORTED_MODULE_126___default.a,
  codeCartoonSelectDifferentCharacter2: _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default.a,
  codeCartoonJump: _steps_code_cartoon_07_jump_uk_png__WEBPACK_IMPORTED_MODULE_128___default.a,
  codeCartoonChangeScenes: _steps_code_cartoon_08_change_scenes_uk_png__WEBPACK_IMPORTED_MODULE_129___default.a,
  codeCartoonGlideAround: _steps_code_cartoon_09_glide_around_uk_png__WEBPACK_IMPORTED_MODULE_130___default.a,
  codeCartoonChangeCostumes: _steps_code_cartoon_10_change_costumes_uk_png__WEBPACK_IMPORTED_MODULE_131___default.a,
  codeCartoonChooseMoreCharacters: _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default.a,
  // Talking Tales
  talesAddExtension: _steps_speech_add_extension_uk_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  talesChooseSprite: _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default.a,
  talesSaySomething: _steps_talking_3_say_something_uk_png__WEBPACK_IMPORTED_MODULE_134___default.a,
  talesAskAnswer: _steps_talking_13_ask_and_answer_uk_png__WEBPACK_IMPORTED_MODULE_144___default.a,
  talesChooseBackdrop: _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default.a,
  talesSwitchBackdrop: _steps_talking_5_switch_backdrop_uk_png__WEBPACK_IMPORTED_MODULE_136___default.a,
  talesChooseAnotherSprite: _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default.a,
  talesMoveAround: _steps_talking_7_move_around_uk_png__WEBPACK_IMPORTED_MODULE_138___default.a,
  talesChooseAnotherBackdrop: _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default.a,
  talesAnimateTalking: _steps_talking_9_animate_uk_png__WEBPACK_IMPORTED_MODULE_140___default.a,
  talesChooseThirdBackdrop: _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default.a,
  talesChooseSound: _steps_talking_11_choose_sound_uk_gif__WEBPACK_IMPORTED_MODULE_142___default.a,
  talesDanceMoves: _steps_talking_12_dance_moves_uk_png__WEBPACK_IMPORTED_MODULE_143___default.a
};


/***/ })

}]);