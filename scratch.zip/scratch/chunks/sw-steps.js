(window["webpackJsonpGUI"] = window["webpackJsonpGUI"] || []).push([[11],{

/***/ 1585:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/074e6f8245cb1506deafdeac71991a5d.gif";

/***/ }),

/***/ 1598:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/99041652f36815b1702b8bc7f019f625.gif";

/***/ }),

/***/ 2464:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b2935b0787ff373cc04c7d2c92de9adb.gif";

/***/ }),

/***/ 2465:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8c2a390eb09d64bc13f4cfa3283fc33f.gif";

/***/ }),

/***/ 2466:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5fdb7c093bfefc2c00ef83fd4c34199e.gif";

/***/ }),

/***/ 2467:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8628ba88ec9dc2777d0e37646513fbb6.png";

/***/ }),

/***/ 2468:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/873d80b60c072af2e25f0ef2a6b38682.png";

/***/ }),

/***/ 2469:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/fd0765acc2eb99d7f88d1a1b236d10c2.png";

/***/ }),

/***/ 2470:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c3786aedc4f52d309d7d570dbaf0f6a5.png";

/***/ }),

/***/ 2471:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/795573a9d2fee5058a63cf5ec067fa3e.png";

/***/ }),

/***/ 2472:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/cdad5959f5916f1de3a6e086b7756c2c.png";

/***/ }),

/***/ 2473:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4901090d1df378dc333fab656582c5b9.png";

/***/ }),

/***/ 2474:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/1b636eacc3c2152c793b7100d0ef5f3d.png";

/***/ }),

/***/ 2475:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/df119834537bf98c8c02f09b1dc40b63.png";

/***/ }),

/***/ 2476:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e47cd5bd430206cefd3a8a5cb4af9138.png";

/***/ }),

/***/ 2477:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f6af8ce94d2a2019c213cf2c0df908b4.png";

/***/ }),

/***/ 2478:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a8547a49cb272a0281b7eab3144043ca.png";

/***/ }),

/***/ 2479:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7691e0682d3855f163ceee281d61e23b.png";

/***/ }),

/***/ 2480:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4edd383da41c26587d94ac5fdfbc3450.png";

/***/ }),

/***/ 2481:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ec6a73c85e83c5db5a1db7134eca25ec.png";

/***/ }),

/***/ 2482:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b5c0d259d78d3d6b7c74e52ccb376a03.png";

/***/ }),

/***/ 2483:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/169f7755a820bb597640f838ccc34af6.png";

/***/ }),

/***/ 2484:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3bf6b664e3628a62c4bc3f6a67b5c2b6.png";

/***/ }),

/***/ 2485:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3d3081fcfb0e88e0c6806aad45d405d2.png";

/***/ }),

/***/ 2486:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4c3354f5536cc0d79df7350b80aa3ef1.png";

/***/ }),

/***/ 2487:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/fcee2fa04b9ae2811c2bd347df8def5e.png";

/***/ }),

/***/ 2488:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c12e386b8137e71b289edca2cca5e500.png";

/***/ }),

/***/ 2489:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/14ff92731b3e54b249ce2d428a3f0f95.png";

/***/ }),

/***/ 2490:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/af02bfe244cded0b63202aa8d0a6ae5a.png";

/***/ }),

/***/ 2491:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3947903ddb159c7e7cd203eb79bda07f.png";

/***/ }),

/***/ 2492:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ea952837ca442a3d64ab17637b787d36.png";

/***/ }),

/***/ 2493:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9918a0206cbd34617d1e61ca58357076.png";

/***/ }),

/***/ 2494:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/af064208b0423eea068b4aa07d183364.png";

/***/ }),

/***/ 2495:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/1dfc1f73867cf8259be121b6b227a2c7.png";

/***/ }),

/***/ 2496:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d02e782a95bdc8bfb7157ad4b92acceb.png";

/***/ }),

/***/ 2497:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/de787f0af75a8a6da1e40057c7b01199.png";

/***/ }),

/***/ 2498:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ec5a678c6318ecbe41949e7e89ae50cf.png";

/***/ }),

/***/ 2499:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b3cd90ba16ab503943c4b0e87b5df175.png";

/***/ }),

/***/ 2500:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/e750462991209bc82f6d0ab0783943c0.png";

/***/ }),

/***/ 2501:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6109659703109e02be27d559070ca726.png";

/***/ }),

/***/ 2502:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a662913c45d963c9548f434c825634b7.png";

/***/ }),

/***/ 2503:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/865309ebdabe1a08b6ae2a7fa8bc4cdf.png";

/***/ }),

/***/ 2504:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/777b12b55dd69be2a1707d31774c71d1.gif";

/***/ }),

/***/ 2505:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/88fc2b4cf2491304618a71d2c94acc68.png";

/***/ }),

/***/ 2506:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b9c886ce0382819a2ae97120a2ba0a7a.png";

/***/ }),

/***/ 2507:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ae21bd02fff4276409bea90e620da158.png";

/***/ }),

/***/ 2508:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d81d8e89d3322c6270e5967a1711403f.png";

/***/ }),

/***/ 2509:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/00cb48b561d398f7e9570ebaeba16211.gif";

/***/ }),

/***/ 2510:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/36770e433b22fecc706efd99c78bcd44.png";

/***/ }),

/***/ 2511:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/cb64c5d445f740053b5079d9331e2607.png";

/***/ }),

/***/ 2512:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/ecf8aab29858b1233a5214116e8da517.png";

/***/ }),

/***/ 2513:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3e3e5f8a22c80c09294ebfc9559ceeac.png";

/***/ }),

/***/ 2514:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/1b63f5631ecfdf2d32b02f5d6de84ea2.png";

/***/ }),

/***/ 2515:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f721f92d4c2e1627652824af85453a07.png";

/***/ }),

/***/ 2516:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/cc7da3f731df277b7281d4f3f43420d9.png";

/***/ }),

/***/ 2517:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/be25fca420a7f95f05e8b87530324c9a.png";

/***/ }),

/***/ 2518:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/246399942353dd551ac62621fd0fc2c7.png";

/***/ }),

/***/ 2519:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/dc685034141f1d53513e90539b4e2436.png";

/***/ }),

/***/ 2520:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/559ff3f97ba4e20648b7846943d9fe33.png";

/***/ }),

/***/ 2521:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/08dff6089c2812aaac7dc2ceed178351.png";

/***/ }),

/***/ 2522:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/f9d3526e16c680095b5cf8543ac3d96e.png";

/***/ }),

/***/ 2523:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8997b5c23c84a4182883356bf17aae34.png";

/***/ }),

/***/ 2524:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/298e234a90ef1161c01bdeeb833fa142.png";

/***/ }),

/***/ 2525:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3d97c0d2dd797f00c614c9c7bdde2850.png";

/***/ }),

/***/ 2526:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2294846969d0c338f497994872451eb7.png";

/***/ }),

/***/ 2527:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/35e5b40c044bd4eb0fc7c261271453e5.png";

/***/ }),

/***/ 2528:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b43cc43126fe68b9f0be90b67f65c3ec.png";

/***/ }),

/***/ 2529:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/8c72b45eaafa254580a22575fb541bc0.png";

/***/ }),

/***/ 2530:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6254575e75d05fe637cc61b7197c2123.png";

/***/ }),

/***/ 2531:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/91935ca9beb1c941b4acfae2115578cc.png";

/***/ }),

/***/ 2532:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9684b10804a422e28712aa058933bd7a.png";

/***/ }),

/***/ 2533:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/6b0a20bccc411ed053bd1df1ee10c154.png";

/***/ }),

/***/ 2534:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a9f68e6391e803ca55d49bdbb536a946.png";

/***/ }),

/***/ 2535:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/2a7c73c010bf5fb6c7cd1021dfb8f39a.gif";

/***/ }),

/***/ 2536:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d8c268c304caec7b98b44bc3675d728a.png";

/***/ }),

/***/ 2537:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c933a7ce574d3814b59f16e5019fc327.png";

/***/ }),

/***/ 2538:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/754baa103c2ac348fe5d6ecca59bea5a.png";

/***/ }),

/***/ 2539:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/a69226a716d526754403451bee941325.png";

/***/ }),

/***/ 2540:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/cb317a2b69045c85ab5eedc7b65ecbcd.png";

/***/ }),

/***/ 2541:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/0b4a4faac5634692886876082f5c99c1.png";

/***/ }),

/***/ 2542:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/431fd7ca74b8eb8ed49519771b2334e6.png";

/***/ }),

/***/ 2543:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/b46e0ae877de42554ae321fb4e9ce420.png";

/***/ }),

/***/ 2544:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/bc6bc02e0931cc10c6507a78b12ae02e.png";

/***/ }),

/***/ 2545:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7541a408ec69080501071d6f06d6bcce.png";

/***/ }),

/***/ 2546:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9de7e20462ee8f25c236dca0172dbc52.png";

/***/ }),

/***/ 2547:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/758ce94395d932d4943f61b3cc96cd1e.png";

/***/ }),

/***/ 2548:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3d3b8fce985f973f14d3ebef6627a7f1.png";

/***/ }),

/***/ 2549:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/5f6e6debfc04be0836d42b45ea85a6bb.png";

/***/ }),

/***/ 2550:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7264c0b67b765f818b43510d45822a3f.png";

/***/ }),

/***/ 2551:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/aaa55abd17e010a1ec92e3285b9b9f1d.png";

/***/ }),

/***/ 2552:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3d01caa7b3aaa53cfd249a1a7a22f7fb.png";

/***/ }),

/***/ 2553:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/17b20e238552e00772bee085bda0b094.png";

/***/ }),

/***/ 2554:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/9ff2f106c8b5d0f7e53714767c7ac869.png";

/***/ }),

/***/ 2555:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/051cc58724149226b23311d799c1c144.png";

/***/ }),

/***/ 2556:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/58e4ffd30e88bef70209f8a88da3f5ca.png";

/***/ }),

/***/ 2557:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/3367a2e5f6357f87d291a31758e14e15.png";

/***/ }),

/***/ 2558:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/797da41ea8725ca406d63babf790766e.png";

/***/ }),

/***/ 2559:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/7f943e03dbb86eddfde951af1c5bafc1.png";

/***/ }),

/***/ 2560:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/855a0d7847380c26af17d003a964103f.png";

/***/ }),

/***/ 2561:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/c6512c99c2c300e1ed16dfc63d514d17.png";

/***/ }),

/***/ 2562:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/d5f612fcbc4be45012074bc10ccd52d1.png";

/***/ }),

/***/ 2563:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/4d3c44e440a7d664dd4dbb11c1413f21.png";

/***/ }),

/***/ 2564:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/61ba3c80aed48940e6a4a699f1f2f6e6.gif";

/***/ }),

/***/ 2565:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/059128109f4c99fd85668e22fefb7b4f.png";

/***/ }),

/***/ 2566:
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__.p + "static/assets/12398f42368ff5cc10c45a38bac8233a.png";

/***/ }),

/***/ 2884:
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "swImages", function() { return swImages; });
/* harmony import */ var _steps_intro_1_move_sw_gif__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2464);
/* harmony import */ var _steps_intro_1_move_sw_gif__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_1_move_sw_gif__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _steps_intro_2_say_sw_gif__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2465);
/* harmony import */ var _steps_intro_2_say_sw_gif__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_2_say_sw_gif__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _steps_intro_3_green_flag_sw_gif__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2466);
/* harmony import */ var _steps_intro_3_green_flag_sw_gif__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_steps_intro_3_green_flag_sw_gif__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _steps_speech_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1598);
/* harmony import */ var _steps_speech_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _steps_speech_say_something_sw_png__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(2467);
/* harmony import */ var _steps_speech_say_something_sw_png__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_say_something_sw_png__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _steps_speech_set_voice_sw_png__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(2468);
/* harmony import */ var _steps_speech_set_voice_sw_png__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_set_voice_sw_png__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _steps_speech_move_around_sw_png__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(2469);
/* harmony import */ var _steps_speech_move_around_sw_png__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_move_around_sw_png__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(233);
/* harmony import */ var _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(386);
/* harmony import */ var _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _steps_speech_song_sw_png__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2470);
/* harmony import */ var _steps_speech_song_sw_png__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_song_sw_png__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _steps_speech_change_color_sw_png__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(2471);
/* harmony import */ var _steps_speech_change_color_sw_png__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_change_color_sw_png__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _steps_speech_spin_sw_png__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(2472);
/* harmony import */ var _steps_speech_spin_sw_png__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_spin_sw_png__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _steps_speech_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(2473);
/* harmony import */ var _steps_speech_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_steps_speech_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(385);
/* harmony import */ var _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _steps_cn_say_sw_png__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(2474);
/* harmony import */ var _steps_cn_say_sw_png__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_say_sw_png__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _steps_cn_glide_sw_png__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(2475);
/* harmony import */ var _steps_cn_glide_sw_png__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_glide_sw_png__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(387);
/* harmony import */ var _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _steps_cn_collect_sw_png__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(2476);
/* harmony import */ var _steps_cn_collect_sw_png__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_collect_sw_png__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(1585);
/* harmony import */ var _steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _steps_cn_score_sw_png__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(2477);
/* harmony import */ var _steps_cn_score_sw_png__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_score_sw_png__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _steps_cn_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(2478);
/* harmony import */ var _steps_cn_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_steps_cn_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(388);
/* harmony import */ var _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(389);
/* harmony import */ var _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _steps_name_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(2479);
/* harmony import */ var _steps_name_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_steps_name_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(390);
/* harmony import */ var _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _steps_name_change_color_sw_png__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(2480);
/* harmony import */ var _steps_name_change_color_sw_png__WEBPACK_IMPORTED_MODULE_25___default = /*#__PURE__*/__webpack_require__.n(_steps_name_change_color_sw_png__WEBPACK_IMPORTED_MODULE_25__);
/* harmony import */ var _steps_name_spin_sw_png__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(2481);
/* harmony import */ var _steps_name_spin_sw_png__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(_steps_name_spin_sw_png__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _steps_name_grow_sw_png__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(2482);
/* harmony import */ var _steps_name_grow_sw_png__WEBPACK_IMPORTED_MODULE_27___default = /*#__PURE__*/__webpack_require__.n(_steps_name_grow_sw_png__WEBPACK_IMPORTED_MODULE_27__);
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(391);
/* harmony import */ var _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default = /*#__PURE__*/__webpack_require__.n(_steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28__);
/* harmony import */ var _steps_music_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_29__ = __webpack_require__(2483);
/* harmony import */ var _steps_music_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_29___default = /*#__PURE__*/__webpack_require__.n(_steps_music_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_29__);
/* harmony import */ var _steps_music_make_song_sw_png__WEBPACK_IMPORTED_MODULE_30__ = __webpack_require__(2484);
/* harmony import */ var _steps_music_make_song_sw_png__WEBPACK_IMPORTED_MODULE_30___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_song_sw_png__WEBPACK_IMPORTED_MODULE_30__);
/* harmony import */ var _steps_music_make_beat_sw_png__WEBPACK_IMPORTED_MODULE_31__ = __webpack_require__(2485);
/* harmony import */ var _steps_music_make_beat_sw_png__WEBPACK_IMPORTED_MODULE_31___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beat_sw_png__WEBPACK_IMPORTED_MODULE_31__);
/* harmony import */ var _steps_music_make_beatbox_sw_png__WEBPACK_IMPORTED_MODULE_32__ = __webpack_require__(2486);
/* harmony import */ var _steps_music_make_beatbox_sw_png__WEBPACK_IMPORTED_MODULE_32___default = /*#__PURE__*/__webpack_require__.n(_steps_music_make_beatbox_sw_png__WEBPACK_IMPORTED_MODULE_32__);
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__ = __webpack_require__(392);
/* harmony import */ var _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33__);
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__ = __webpack_require__(393);
/* harmony import */ var _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34__);
/* harmony import */ var _steps_chase_game_right_left_sw_png__WEBPACK_IMPORTED_MODULE_35__ = __webpack_require__(2487);
/* harmony import */ var _steps_chase_game_right_left_sw_png__WEBPACK_IMPORTED_MODULE_35___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_right_left_sw_png__WEBPACK_IMPORTED_MODULE_35__);
/* harmony import */ var _steps_chase_game_up_down_sw_png__WEBPACK_IMPORTED_MODULE_36__ = __webpack_require__(2488);
/* harmony import */ var _steps_chase_game_up_down_sw_png__WEBPACK_IMPORTED_MODULE_36___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_up_down_sw_png__WEBPACK_IMPORTED_MODULE_36__);
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__ = __webpack_require__(394);
/* harmony import */ var _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37__);
/* harmony import */ var _steps_chase_game_move_randomly_sw_png__WEBPACK_IMPORTED_MODULE_38__ = __webpack_require__(2489);
/* harmony import */ var _steps_chase_game_move_randomly_sw_png__WEBPACK_IMPORTED_MODULE_38___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_move_randomly_sw_png__WEBPACK_IMPORTED_MODULE_38__);
/* harmony import */ var _steps_chase_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_39__ = __webpack_require__(2490);
/* harmony import */ var _steps_chase_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_39___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_39__);
/* harmony import */ var _steps_chase_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_40__ = __webpack_require__(2491);
/* harmony import */ var _steps_chase_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_40___default = /*#__PURE__*/__webpack_require__.n(_steps_chase_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_40__);
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__ = __webpack_require__(395);
/* harmony import */ var _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41__);
/* harmony import */ var _steps_pop_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_42__ = __webpack_require__(2492);
/* harmony import */ var _steps_pop_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_42___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_42__);
/* harmony import */ var _steps_pop_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_43__ = __webpack_require__(2493);
/* harmony import */ var _steps_pop_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_43___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_43__);
/* harmony import */ var _steps_pop_game_random_position_sw_png__WEBPACK_IMPORTED_MODULE_44__ = __webpack_require__(2494);
/* harmony import */ var _steps_pop_game_random_position_sw_png__WEBPACK_IMPORTED_MODULE_44___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_random_position_sw_png__WEBPACK_IMPORTED_MODULE_44__);
/* harmony import */ var _steps_pop_game_change_color_sw_png__WEBPACK_IMPORTED_MODULE_45__ = __webpack_require__(2495);
/* harmony import */ var _steps_pop_game_change_color_sw_png__WEBPACK_IMPORTED_MODULE_45___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_change_color_sw_png__WEBPACK_IMPORTED_MODULE_45__);
/* harmony import */ var _steps_pop_game_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_46__ = __webpack_require__(2496);
/* harmony import */ var _steps_pop_game_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_46___default = /*#__PURE__*/__webpack_require__.n(_steps_pop_game_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_46__);
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__ = __webpack_require__(396);
/* harmony import */ var _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47__);
/* harmony import */ var _steps_animate_char_say_something_sw_png__WEBPACK_IMPORTED_MODULE_48__ = __webpack_require__(2497);
/* harmony import */ var _steps_animate_char_say_something_sw_png__WEBPACK_IMPORTED_MODULE_48___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_say_something_sw_png__WEBPACK_IMPORTED_MODULE_48__);
/* harmony import */ var _steps_animate_char_add_sound_sw_png__WEBPACK_IMPORTED_MODULE_49__ = __webpack_require__(2498);
/* harmony import */ var _steps_animate_char_add_sound_sw_png__WEBPACK_IMPORTED_MODULE_49___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_add_sound_sw_png__WEBPACK_IMPORTED_MODULE_49__);
/* harmony import */ var _steps_animate_char_talk_sw_png__WEBPACK_IMPORTED_MODULE_50__ = __webpack_require__(2499);
/* harmony import */ var _steps_animate_char_talk_sw_png__WEBPACK_IMPORTED_MODULE_50___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_talk_sw_png__WEBPACK_IMPORTED_MODULE_50__);
/* harmony import */ var _steps_animate_char_move_sw_png__WEBPACK_IMPORTED_MODULE_51__ = __webpack_require__(2500);
/* harmony import */ var _steps_animate_char_move_sw_png__WEBPACK_IMPORTED_MODULE_51___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_move_sw_png__WEBPACK_IMPORTED_MODULE_51__);
/* harmony import */ var _steps_animate_char_jump_sw_png__WEBPACK_IMPORTED_MODULE_52__ = __webpack_require__(2501);
/* harmony import */ var _steps_animate_char_jump_sw_png__WEBPACK_IMPORTED_MODULE_52___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_jump_sw_png__WEBPACK_IMPORTED_MODULE_52__);
/* harmony import */ var _steps_animate_char_change_color_sw_png__WEBPACK_IMPORTED_MODULE_53__ = __webpack_require__(2502);
/* harmony import */ var _steps_animate_char_change_color_sw_png__WEBPACK_IMPORTED_MODULE_53___default = /*#__PURE__*/__webpack_require__.n(_steps_animate_char_change_color_sw_png__WEBPACK_IMPORTED_MODULE_53__);
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__ = __webpack_require__(397);
/* harmony import */ var _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54__);
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__ = __webpack_require__(398);
/* harmony import */ var _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55__);
/* harmony import */ var _steps_story_say_something_sw_png__WEBPACK_IMPORTED_MODULE_56__ = __webpack_require__(2503);
/* harmony import */ var _steps_story_say_something_sw_png__WEBPACK_IMPORTED_MODULE_56___default = /*#__PURE__*/__webpack_require__.n(_steps_story_say_something_sw_png__WEBPACK_IMPORTED_MODULE_56__);
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__ = __webpack_require__(399);
/* harmony import */ var _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57__);
/* harmony import */ var _steps_story_flip_sw_gif__WEBPACK_IMPORTED_MODULE_58__ = __webpack_require__(2504);
/* harmony import */ var _steps_story_flip_sw_gif__WEBPACK_IMPORTED_MODULE_58___default = /*#__PURE__*/__webpack_require__.n(_steps_story_flip_sw_gif__WEBPACK_IMPORTED_MODULE_58__);
/* harmony import */ var _steps_story_conversation_sw_png__WEBPACK_IMPORTED_MODULE_59__ = __webpack_require__(2505);
/* harmony import */ var _steps_story_conversation_sw_png__WEBPACK_IMPORTED_MODULE_59___default = /*#__PURE__*/__webpack_require__.n(_steps_story_conversation_sw_png__WEBPACK_IMPORTED_MODULE_59__);
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__ = __webpack_require__(400);
/* harmony import */ var _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default = /*#__PURE__*/__webpack_require__.n(_steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60__);
/* harmony import */ var _steps_story_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_61__ = __webpack_require__(2506);
/* harmony import */ var _steps_story_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_61___default = /*#__PURE__*/__webpack_require__.n(_steps_story_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_61__);
/* harmony import */ var _steps_story_hide_character_sw_png__WEBPACK_IMPORTED_MODULE_62__ = __webpack_require__(2507);
/* harmony import */ var _steps_story_hide_character_sw_png__WEBPACK_IMPORTED_MODULE_62___default = /*#__PURE__*/__webpack_require__.n(_steps_story_hide_character_sw_png__WEBPACK_IMPORTED_MODULE_62__);
/* harmony import */ var _steps_story_show_character_sw_png__WEBPACK_IMPORTED_MODULE_63__ = __webpack_require__(2508);
/* harmony import */ var _steps_story_show_character_sw_png__WEBPACK_IMPORTED_MODULE_63___default = /*#__PURE__*/__webpack_require__.n(_steps_story_show_character_sw_png__WEBPACK_IMPORTED_MODULE_63__);
/* harmony import */ var _steps_video_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_64__ = __webpack_require__(2509);
/* harmony import */ var _steps_video_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_64___default = /*#__PURE__*/__webpack_require__.n(_steps_video_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_64__);
/* harmony import */ var _steps_video_pet_sw_png__WEBPACK_IMPORTED_MODULE_65__ = __webpack_require__(2510);
/* harmony import */ var _steps_video_pet_sw_png__WEBPACK_IMPORTED_MODULE_65___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pet_sw_png__WEBPACK_IMPORTED_MODULE_65__);
/* harmony import */ var _steps_video_animate_sw_png__WEBPACK_IMPORTED_MODULE_66__ = __webpack_require__(2511);
/* harmony import */ var _steps_video_animate_sw_png__WEBPACK_IMPORTED_MODULE_66___default = /*#__PURE__*/__webpack_require__.n(_steps_video_animate_sw_png__WEBPACK_IMPORTED_MODULE_66__);
/* harmony import */ var _steps_video_pop_sw_png__WEBPACK_IMPORTED_MODULE_67__ = __webpack_require__(2512);
/* harmony import */ var _steps_video_pop_sw_png__WEBPACK_IMPORTED_MODULE_67___default = /*#__PURE__*/__webpack_require__.n(_steps_video_pop_sw_png__WEBPACK_IMPORTED_MODULE_67__);
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__ = __webpack_require__(401);
/* harmony import */ var _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68__);
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__ = __webpack_require__(402);
/* harmony import */ var _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69__);
/* harmony import */ var _steps_fly_say_something_sw_png__WEBPACK_IMPORTED_MODULE_70__ = __webpack_require__(2513);
/* harmony import */ var _steps_fly_say_something_sw_png__WEBPACK_IMPORTED_MODULE_70___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_say_something_sw_png__WEBPACK_IMPORTED_MODULE_70__);
/* harmony import */ var _steps_fly_make_interactive_sw_png__WEBPACK_IMPORTED_MODULE_71__ = __webpack_require__(2514);
/* harmony import */ var _steps_fly_make_interactive_sw_png__WEBPACK_IMPORTED_MODULE_71___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_make_interactive_sw_png__WEBPACK_IMPORTED_MODULE_71__);
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__ = __webpack_require__(403);
/* harmony import */ var _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72__);
/* harmony import */ var _steps_fly_flying_heart_sw_png__WEBPACK_IMPORTED_MODULE_73__ = __webpack_require__(2515);
/* harmony import */ var _steps_fly_flying_heart_sw_png__WEBPACK_IMPORTED_MODULE_73___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_flying_heart_sw_png__WEBPACK_IMPORTED_MODULE_73__);
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__ = __webpack_require__(404);
/* harmony import */ var _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74__);
/* harmony import */ var _steps_fly_keep_score_sw_png__WEBPACK_IMPORTED_MODULE_75__ = __webpack_require__(2516);
/* harmony import */ var _steps_fly_keep_score_sw_png__WEBPACK_IMPORTED_MODULE_75___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_keep_score_sw_png__WEBPACK_IMPORTED_MODULE_75__);
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__ = __webpack_require__(405);
/* harmony import */ var _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76__);
/* harmony import */ var _steps_fly_move_scenery_sw_png__WEBPACK_IMPORTED_MODULE_77__ = __webpack_require__(2517);
/* harmony import */ var _steps_fly_move_scenery_sw_png__WEBPACK_IMPORTED_MODULE_77___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_move_scenery_sw_png__WEBPACK_IMPORTED_MODULE_77__);
/* harmony import */ var _steps_fly_switch_costume_sw_png__WEBPACK_IMPORTED_MODULE_78__ = __webpack_require__(2518);
/* harmony import */ var _steps_fly_switch_costume_sw_png__WEBPACK_IMPORTED_MODULE_78___default = /*#__PURE__*/__webpack_require__.n(_steps_fly_switch_costume_sw_png__WEBPACK_IMPORTED_MODULE_78__);
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__ = __webpack_require__(406);
/* harmony import */ var _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79__);
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__ = __webpack_require__(407);
/* harmony import */ var _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80__);
/* harmony import */ var _steps_pong_bounce_around_sw_png__WEBPACK_IMPORTED_MODULE_81__ = __webpack_require__(2519);
/* harmony import */ var _steps_pong_bounce_around_sw_png__WEBPACK_IMPORTED_MODULE_81___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_bounce_around_sw_png__WEBPACK_IMPORTED_MODULE_81__);
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__ = __webpack_require__(408);
/* harmony import */ var _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82__);
/* harmony import */ var _steps_pong_move_the_paddle_sw_png__WEBPACK_IMPORTED_MODULE_83__ = __webpack_require__(2520);
/* harmony import */ var _steps_pong_move_the_paddle_sw_png__WEBPACK_IMPORTED_MODULE_83___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_move_the_paddle_sw_png__WEBPACK_IMPORTED_MODULE_83__);
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__ = __webpack_require__(409);
/* harmony import */ var _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84__);
/* harmony import */ var _steps_pong_add_code_to_ball_sw_png__WEBPACK_IMPORTED_MODULE_85__ = __webpack_require__(2521);
/* harmony import */ var _steps_pong_add_code_to_ball_sw_png__WEBPACK_IMPORTED_MODULE_85___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_code_to_ball_sw_png__WEBPACK_IMPORTED_MODULE_85__);
/* harmony import */ var _steps_pong_choose_score_sw_png__WEBPACK_IMPORTED_MODULE_86__ = __webpack_require__(2522);
/* harmony import */ var _steps_pong_choose_score_sw_png__WEBPACK_IMPORTED_MODULE_86___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_choose_score_sw_png__WEBPACK_IMPORTED_MODULE_86__);
/* harmony import */ var _steps_pong_insert_change_score_sw_png__WEBPACK_IMPORTED_MODULE_87__ = __webpack_require__(2523);
/* harmony import */ var _steps_pong_insert_change_score_sw_png__WEBPACK_IMPORTED_MODULE_87___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_insert_change_score_sw_png__WEBPACK_IMPORTED_MODULE_87__);
/* harmony import */ var _steps_pong_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_88__ = __webpack_require__(2524);
/* harmony import */ var _steps_pong_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_88___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_88__);
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__ = __webpack_require__(410);
/* harmony import */ var _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89__);
/* harmony import */ var _steps_pong_game_over_sw_png__WEBPACK_IMPORTED_MODULE_90__ = __webpack_require__(2525);
/* harmony import */ var _steps_pong_game_over_sw_png__WEBPACK_IMPORTED_MODULE_90___default = /*#__PURE__*/__webpack_require__.n(_steps_pong_game_over_sw_png__WEBPACK_IMPORTED_MODULE_90__);
/* harmony import */ var _steps_imagine_type_what_you_want_sw_png__WEBPACK_IMPORTED_MODULE_91__ = __webpack_require__(2526);
/* harmony import */ var _steps_imagine_type_what_you_want_sw_png__WEBPACK_IMPORTED_MODULE_91___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_type_what_you_want_sw_png__WEBPACK_IMPORTED_MODULE_91__);
/* harmony import */ var _steps_imagine_click_green_flag_sw_png__WEBPACK_IMPORTED_MODULE_92__ = __webpack_require__(2527);
/* harmony import */ var _steps_imagine_click_green_flag_sw_png__WEBPACK_IMPORTED_MODULE_92___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_click_green_flag_sw_png__WEBPACK_IMPORTED_MODULE_92__);
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__ = __webpack_require__(411);
/* harmony import */ var _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93__);
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__ = __webpack_require__(412);
/* harmony import */ var _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94__);
/* harmony import */ var _steps_imagine_fly_around_sw_png__WEBPACK_IMPORTED_MODULE_95__ = __webpack_require__(2528);
/* harmony import */ var _steps_imagine_fly_around_sw_png__WEBPACK_IMPORTED_MODULE_95___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_fly_around_sw_png__WEBPACK_IMPORTED_MODULE_95__);
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__ = __webpack_require__(413);
/* harmony import */ var _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96__);
/* harmony import */ var _steps_imagine_left_right_sw_png__WEBPACK_IMPORTED_MODULE_97__ = __webpack_require__(2529);
/* harmony import */ var _steps_imagine_left_right_sw_png__WEBPACK_IMPORTED_MODULE_97___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_left_right_sw_png__WEBPACK_IMPORTED_MODULE_97__);
/* harmony import */ var _steps_imagine_up_down_sw_png__WEBPACK_IMPORTED_MODULE_98__ = __webpack_require__(2530);
/* harmony import */ var _steps_imagine_up_down_sw_png__WEBPACK_IMPORTED_MODULE_98___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_up_down_sw_png__WEBPACK_IMPORTED_MODULE_98__);
/* harmony import */ var _steps_imagine_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_99__ = __webpack_require__(2531);
/* harmony import */ var _steps_imagine_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_99___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_99__);
/* harmony import */ var _steps_imagine_glide_to_point_sw_png__WEBPACK_IMPORTED_MODULE_100__ = __webpack_require__(2532);
/* harmony import */ var _steps_imagine_glide_to_point_sw_png__WEBPACK_IMPORTED_MODULE_100___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_glide_to_point_sw_png__WEBPACK_IMPORTED_MODULE_100__);
/* harmony import */ var _steps_imagine_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_101__ = __webpack_require__(2533);
/* harmony import */ var _steps_imagine_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_101___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_101__);
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__ = __webpack_require__(414);
/* harmony import */ var _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102__);
/* harmony import */ var _steps_imagine_switch_backdrops_sw_png__WEBPACK_IMPORTED_MODULE_103__ = __webpack_require__(2534);
/* harmony import */ var _steps_imagine_switch_backdrops_sw_png__WEBPACK_IMPORTED_MODULE_103___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_switch_backdrops_sw_png__WEBPACK_IMPORTED_MODULE_103__);
/* harmony import */ var _steps_imagine_record_a_sound_sw_gif__WEBPACK_IMPORTED_MODULE_104__ = __webpack_require__(2535);
/* harmony import */ var _steps_imagine_record_a_sound_sw_gif__WEBPACK_IMPORTED_MODULE_104___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_record_a_sound_sw_gif__WEBPACK_IMPORTED_MODULE_104__);
/* harmony import */ var _steps_imagine_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_105__ = __webpack_require__(2536);
/* harmony import */ var _steps_imagine_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_105___default = /*#__PURE__*/__webpack_require__.n(_steps_imagine_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_105__);
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__ = __webpack_require__(415);
/* harmony import */ var _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default = /*#__PURE__*/__webpack_require__.n(_steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106__);
/* harmony import */ var _steps_add_effects_sw_png__WEBPACK_IMPORTED_MODULE_107__ = __webpack_require__(2537);
/* harmony import */ var _steps_add_effects_sw_png__WEBPACK_IMPORTED_MODULE_107___default = /*#__PURE__*/__webpack_require__.n(_steps_add_effects_sw_png__WEBPACK_IMPORTED_MODULE_107__);
/* harmony import */ var _steps_hide_show_sw_png__WEBPACK_IMPORTED_MODULE_108__ = __webpack_require__(2538);
/* harmony import */ var _steps_hide_show_sw_png__WEBPACK_IMPORTED_MODULE_108___default = /*#__PURE__*/__webpack_require__.n(_steps_hide_show_sw_png__WEBPACK_IMPORTED_MODULE_108__);
/* harmony import */ var _steps_switch_costumes_sw_png__WEBPACK_IMPORTED_MODULE_109__ = __webpack_require__(2539);
/* harmony import */ var _steps_switch_costumes_sw_png__WEBPACK_IMPORTED_MODULE_109___default = /*#__PURE__*/__webpack_require__.n(_steps_switch_costumes_sw_png__WEBPACK_IMPORTED_MODULE_109__);
/* harmony import */ var _steps_change_size_sw_png__WEBPACK_IMPORTED_MODULE_110__ = __webpack_require__(2540);
/* harmony import */ var _steps_change_size_sw_png__WEBPACK_IMPORTED_MODULE_110___default = /*#__PURE__*/__webpack_require__.n(_steps_change_size_sw_png__WEBPACK_IMPORTED_MODULE_110__);
/* harmony import */ var _steps_spin_turn_sw_png__WEBPACK_IMPORTED_MODULE_111__ = __webpack_require__(2541);
/* harmony import */ var _steps_spin_turn_sw_png__WEBPACK_IMPORTED_MODULE_111___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_turn_sw_png__WEBPACK_IMPORTED_MODULE_111__);
/* harmony import */ var _steps_spin_point_in_direction_sw_png__WEBPACK_IMPORTED_MODULE_112__ = __webpack_require__(2542);
/* harmony import */ var _steps_spin_point_in_direction_sw_png__WEBPACK_IMPORTED_MODULE_112___default = /*#__PURE__*/__webpack_require__.n(_steps_spin_point_in_direction_sw_png__WEBPACK_IMPORTED_MODULE_112__);
/* harmony import */ var _steps_record_a_sound_sounds_tab_sw_png__WEBPACK_IMPORTED_MODULE_113__ = __webpack_require__(2543);
/* harmony import */ var _steps_record_a_sound_sounds_tab_sw_png__WEBPACK_IMPORTED_MODULE_113___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_sounds_tab_sw_png__WEBPACK_IMPORTED_MODULE_113__);
/* harmony import */ var _steps_record_a_sound_click_record_sw_png__WEBPACK_IMPORTED_MODULE_114__ = __webpack_require__(2544);
/* harmony import */ var _steps_record_a_sound_click_record_sw_png__WEBPACK_IMPORTED_MODULE_114___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_click_record_sw_png__WEBPACK_IMPORTED_MODULE_114__);
/* harmony import */ var _steps_record_a_sound_press_record_button_sw_png__WEBPACK_IMPORTED_MODULE_115__ = __webpack_require__(2545);
/* harmony import */ var _steps_record_a_sound_press_record_button_sw_png__WEBPACK_IMPORTED_MODULE_115___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_press_record_button_sw_png__WEBPACK_IMPORTED_MODULE_115__);
/* harmony import */ var _steps_record_a_sound_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_116__ = __webpack_require__(2546);
/* harmony import */ var _steps_record_a_sound_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_116___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_116__);
/* harmony import */ var _steps_record_a_sound_play_your_sound_sw_png__WEBPACK_IMPORTED_MODULE_117__ = __webpack_require__(2547);
/* harmony import */ var _steps_record_a_sound_play_your_sound_sw_png__WEBPACK_IMPORTED_MODULE_117___default = /*#__PURE__*/__webpack_require__.n(_steps_record_a_sound_play_your_sound_sw_png__WEBPACK_IMPORTED_MODULE_117__);
/* harmony import */ var _steps_move_arrow_keys_left_right_sw_png__WEBPACK_IMPORTED_MODULE_118__ = __webpack_require__(2548);
/* harmony import */ var _steps_move_arrow_keys_left_right_sw_png__WEBPACK_IMPORTED_MODULE_118___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_left_right_sw_png__WEBPACK_IMPORTED_MODULE_118__);
/* harmony import */ var _steps_move_arrow_keys_up_down_sw_png__WEBPACK_IMPORTED_MODULE_119__ = __webpack_require__(2549);
/* harmony import */ var _steps_move_arrow_keys_up_down_sw_png__WEBPACK_IMPORTED_MODULE_119___default = /*#__PURE__*/__webpack_require__.n(_steps_move_arrow_keys_up_down_sw_png__WEBPACK_IMPORTED_MODULE_119__);
/* harmony import */ var _steps_glide_around_back_and_forth_sw_png__WEBPACK_IMPORTED_MODULE_120__ = __webpack_require__(2550);
/* harmony import */ var _steps_glide_around_back_and_forth_sw_png__WEBPACK_IMPORTED_MODULE_120___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_back_and_forth_sw_png__WEBPACK_IMPORTED_MODULE_120__);
/* harmony import */ var _steps_glide_around_point_sw_png__WEBPACK_IMPORTED_MODULE_121__ = __webpack_require__(2551);
/* harmony import */ var _steps_glide_around_point_sw_png__WEBPACK_IMPORTED_MODULE_121___default = /*#__PURE__*/__webpack_require__.n(_steps_glide_around_point_sw_png__WEBPACK_IMPORTED_MODULE_121__);
/* harmony import */ var _steps_code_cartoon_01_say_something_sw_png__WEBPACK_IMPORTED_MODULE_122__ = __webpack_require__(2552);
/* harmony import */ var _steps_code_cartoon_01_say_something_sw_png__WEBPACK_IMPORTED_MODULE_122___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_01_say_something_sw_png__WEBPACK_IMPORTED_MODULE_122__);
/* harmony import */ var _steps_code_cartoon_02_animate_sw_png__WEBPACK_IMPORTED_MODULE_123__ = __webpack_require__(2553);
/* harmony import */ var _steps_code_cartoon_02_animate_sw_png__WEBPACK_IMPORTED_MODULE_123___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_02_animate_sw_png__WEBPACK_IMPORTED_MODULE_123__);
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__ = __webpack_require__(416);
/* harmony import */ var _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124__);
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_sw_png__WEBPACK_IMPORTED_MODULE_125__ = __webpack_require__(2554);
/* harmony import */ var _steps_code_cartoon_04_use_minus_sign_sw_png__WEBPACK_IMPORTED_MODULE_125___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_04_use_minus_sign_sw_png__WEBPACK_IMPORTED_MODULE_125__);
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_126__ = __webpack_require__(2555);
/* harmony import */ var _steps_code_cartoon_05_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_126___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_05_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_126__);
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__ = __webpack_require__(417);
/* harmony import */ var _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127__);
/* harmony import */ var _steps_code_cartoon_07_jump_sw_png__WEBPACK_IMPORTED_MODULE_128__ = __webpack_require__(2556);
/* harmony import */ var _steps_code_cartoon_07_jump_sw_png__WEBPACK_IMPORTED_MODULE_128___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_07_jump_sw_png__WEBPACK_IMPORTED_MODULE_128__);
/* harmony import */ var _steps_code_cartoon_08_change_scenes_sw_png__WEBPACK_IMPORTED_MODULE_129__ = __webpack_require__(2557);
/* harmony import */ var _steps_code_cartoon_08_change_scenes_sw_png__WEBPACK_IMPORTED_MODULE_129___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_08_change_scenes_sw_png__WEBPACK_IMPORTED_MODULE_129__);
/* harmony import */ var _steps_code_cartoon_09_glide_around_sw_png__WEBPACK_IMPORTED_MODULE_130__ = __webpack_require__(2558);
/* harmony import */ var _steps_code_cartoon_09_glide_around_sw_png__WEBPACK_IMPORTED_MODULE_130___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_09_glide_around_sw_png__WEBPACK_IMPORTED_MODULE_130__);
/* harmony import */ var _steps_code_cartoon_10_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_131__ = __webpack_require__(2559);
/* harmony import */ var _steps_code_cartoon_10_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_131___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_10_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_131__);
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__ = __webpack_require__(418);
/* harmony import */ var _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default = /*#__PURE__*/__webpack_require__.n(_steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132__);
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__ = __webpack_require__(419);
/* harmony import */ var _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133__);
/* harmony import */ var _steps_talking_3_say_something_sw_png__WEBPACK_IMPORTED_MODULE_134__ = __webpack_require__(2560);
/* harmony import */ var _steps_talking_3_say_something_sw_png__WEBPACK_IMPORTED_MODULE_134___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_3_say_something_sw_png__WEBPACK_IMPORTED_MODULE_134__);
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__ = __webpack_require__(420);
/* harmony import */ var _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135__);
/* harmony import */ var _steps_talking_5_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_136__ = __webpack_require__(2561);
/* harmony import */ var _steps_talking_5_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_136___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_5_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_136__);
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__ = __webpack_require__(421);
/* harmony import */ var _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137__);
/* harmony import */ var _steps_talking_7_move_around_sw_png__WEBPACK_IMPORTED_MODULE_138__ = __webpack_require__(2562);
/* harmony import */ var _steps_talking_7_move_around_sw_png__WEBPACK_IMPORTED_MODULE_138___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_7_move_around_sw_png__WEBPACK_IMPORTED_MODULE_138__);
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__ = __webpack_require__(422);
/* harmony import */ var _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139__);
/* harmony import */ var _steps_talking_9_animate_sw_png__WEBPACK_IMPORTED_MODULE_140__ = __webpack_require__(2563);
/* harmony import */ var _steps_talking_9_animate_sw_png__WEBPACK_IMPORTED_MODULE_140___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_9_animate_sw_png__WEBPACK_IMPORTED_MODULE_140__);
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__ = __webpack_require__(423);
/* harmony import */ var _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141__);
/* harmony import */ var _steps_talking_11_choose_sound_sw_gif__WEBPACK_IMPORTED_MODULE_142__ = __webpack_require__(2564);
/* harmony import */ var _steps_talking_11_choose_sound_sw_gif__WEBPACK_IMPORTED_MODULE_142___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_11_choose_sound_sw_gif__WEBPACK_IMPORTED_MODULE_142__);
/* harmony import */ var _steps_talking_12_dance_moves_sw_png__WEBPACK_IMPORTED_MODULE_143__ = __webpack_require__(2565);
/* harmony import */ var _steps_talking_12_dance_moves_sw_png__WEBPACK_IMPORTED_MODULE_143___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_12_dance_moves_sw_png__WEBPACK_IMPORTED_MODULE_143__);
/* harmony import */ var _steps_talking_13_ask_and_answer_sw_png__WEBPACK_IMPORTED_MODULE_144__ = __webpack_require__(2566);
/* harmony import */ var _steps_talking_13_ask_and_answer_sw_png__WEBPACK_IMPORTED_MODULE_144___default = /*#__PURE__*/__webpack_require__.n(_steps_talking_13_ask_and_answer_sw_png__WEBPACK_IMPORTED_MODULE_144__);
// Intro


 // Text to Speech










 // Cartoon Network








 // Add sprite

 // Animate a name






 // Make Music





 // Chase-Game









 // Clicker-Game (Pop Game)







 // Animate A Character








 // Tell A Story










 // Video Sensing




 // Make it Fly












 // Pong













 // Imagine a World















 // Add a Backdrop

 // Add Effects

 // Hide and Show

 // Switch Costumes

 // Change Size

 // Spin


 // Record a Sound





 // Use Arrow Keys


 // Glide Around


 // Code a Cartoon











 // Talking Tales














var swImages = {
  // Intro
  introMove: _steps_intro_1_move_sw_gif__WEBPACK_IMPORTED_MODULE_0___default.a,
  introSay: _steps_intro_2_say_sw_gif__WEBPACK_IMPORTED_MODULE_1___default.a,
  introGreenFlag: _steps_intro_3_green_flag_sw_gif__WEBPACK_IMPORTED_MODULE_2___default.a,
  // Text to Speech
  speechAddExtension: _steps_speech_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  speechSaySomething: _steps_speech_say_something_sw_png__WEBPACK_IMPORTED_MODULE_4___default.a,
  speechSetVoice: _steps_speech_set_voice_sw_png__WEBPACK_IMPORTED_MODULE_5___default.a,
  speechMoveAround: _steps_speech_move_around_sw_png__WEBPACK_IMPORTED_MODULE_6___default.a,
  speechAddBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  speechAddSprite: _steps_speech_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_8___default.a,
  speechSong: _steps_speech_song_sw_png__WEBPACK_IMPORTED_MODULE_9___default.a,
  speechChangeColor: _steps_speech_change_color_sw_png__WEBPACK_IMPORTED_MODULE_10___default.a,
  speechSpin: _steps_speech_spin_sw_png__WEBPACK_IMPORTED_MODULE_11___default.a,
  speechGrowShrink: _steps_speech_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_12___default.a,
  // Cartoon Network
  cnShowCharacter: _steps_cn_show_character_LTR_gif__WEBPACK_IMPORTED_MODULE_13___default.a,
  cnSay: _steps_cn_say_sw_png__WEBPACK_IMPORTED_MODULE_14___default.a,
  cnGlide: _steps_cn_glide_sw_png__WEBPACK_IMPORTED_MODULE_15___default.a,
  cnPickSprite: _steps_cn_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_16___default.a,
  cnCollect: _steps_cn_collect_sw_png__WEBPACK_IMPORTED_MODULE_17___default.a,
  cnVariable: _steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  cnScore: _steps_cn_score_sw_png__WEBPACK_IMPORTED_MODULE_19___default.a,
  cnBackdrop: _steps_cn_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_20___default.a,
  // Add sprite
  addSprite: _steps_add_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_21___default.a,
  // Animate a name
  namePickLetter: _steps_name_pick_letter_LTR_gif__WEBPACK_IMPORTED_MODULE_22___default.a,
  namePlaySound: _steps_name_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_23___default.a,
  namePickLetter2: _steps_name_pick_letter2_LTR_gif__WEBPACK_IMPORTED_MODULE_24___default.a,
  nameChangeColor: _steps_name_change_color_sw_png__WEBPACK_IMPORTED_MODULE_25___default.a,
  nameSpin: _steps_name_spin_sw_png__WEBPACK_IMPORTED_MODULE_26___default.a,
  nameGrow: _steps_name_grow_sw_png__WEBPACK_IMPORTED_MODULE_27___default.a,
  // Make-Music
  musicPickInstrument: _steps_music_pick_instrument_LTR_gif__WEBPACK_IMPORTED_MODULE_28___default.a,
  musicPlaySound: _steps_music_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_29___default.a,
  musicMakeSong: _steps_music_make_song_sw_png__WEBPACK_IMPORTED_MODULE_30___default.a,
  musicMakeBeat: _steps_music_make_beat_sw_png__WEBPACK_IMPORTED_MODULE_31___default.a,
  musicMakeBeatbox: _steps_music_make_beatbox_sw_png__WEBPACK_IMPORTED_MODULE_32___default.a,
  // Chase-Game
  chaseGameAddBackdrop: _steps_chase_game_add_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_33___default.a,
  chaseGameAddSprite1: _steps_chase_game_add_sprite1_LTR_gif__WEBPACK_IMPORTED_MODULE_34___default.a,
  chaseGameRightLeft: _steps_chase_game_right_left_sw_png__WEBPACK_IMPORTED_MODULE_35___default.a,
  chaseGameUpDown: _steps_chase_game_up_down_sw_png__WEBPACK_IMPORTED_MODULE_36___default.a,
  chaseGameAddSprite2: _steps_chase_game_add_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_37___default.a,
  chaseGameMoveRandomly: _steps_chase_game_move_randomly_sw_png__WEBPACK_IMPORTED_MODULE_38___default.a,
  chaseGamePlaySound: _steps_chase_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_39___default.a,
  chaseGameAddVariable: _steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  chaseGameChangeScore: _steps_chase_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_40___default.a,
  // Make-A-Pop/Clicker Game
  popGamePickSprite: _steps_pop_game_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_41___default.a,
  popGamePlaySound: _steps_pop_game_play_sound_sw_png__WEBPACK_IMPORTED_MODULE_42___default.a,
  popGameAddScore: _steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  popGameChangeScore: _steps_pop_game_change_score_sw_png__WEBPACK_IMPORTED_MODULE_43___default.a,
  popGameRandomPosition: _steps_pop_game_random_position_sw_png__WEBPACK_IMPORTED_MODULE_44___default.a,
  popGameChangeColor: _steps_pop_game_change_color_sw_png__WEBPACK_IMPORTED_MODULE_45___default.a,
  popGameResetScore: _steps_pop_game_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_46___default.a,
  // Animate A Character
  animateCharPickBackdrop: _steps_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_7___default.a,
  animateCharPickSprite: _steps_animate_char_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_47___default.a,
  animateCharSaySomething: _steps_animate_char_say_something_sw_png__WEBPACK_IMPORTED_MODULE_48___default.a,
  animateCharAddSound: _steps_animate_char_add_sound_sw_png__WEBPACK_IMPORTED_MODULE_49___default.a,
  animateCharTalk: _steps_animate_char_talk_sw_png__WEBPACK_IMPORTED_MODULE_50___default.a,
  animateCharMove: _steps_animate_char_move_sw_png__WEBPACK_IMPORTED_MODULE_51___default.a,
  animateCharJump: _steps_animate_char_jump_sw_png__WEBPACK_IMPORTED_MODULE_52___default.a,
  animateCharChangeColor: _steps_animate_char_change_color_sw_png__WEBPACK_IMPORTED_MODULE_53___default.a,
  // Tell A Story
  storyPickBackdrop: _steps_story_pick_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_54___default.a,
  storyPickSprite: _steps_story_pick_sprite_LTR_gif__WEBPACK_IMPORTED_MODULE_55___default.a,
  storySaySomething: _steps_story_say_something_sw_png__WEBPACK_IMPORTED_MODULE_56___default.a,
  storyPickSprite2: _steps_story_pick_sprite2_LTR_gif__WEBPACK_IMPORTED_MODULE_57___default.a,
  storyFlip: _steps_story_flip_sw_gif__WEBPACK_IMPORTED_MODULE_58___default.a,
  storyConversation: _steps_story_conversation_sw_png__WEBPACK_IMPORTED_MODULE_59___default.a,
  storyPickBackdrop2: _steps_story_pick_backdrop2_LTR_gif__WEBPACK_IMPORTED_MODULE_60___default.a,
  storySwitchBackdrop: _steps_story_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_61___default.a,
  storyHideCharacter: _steps_story_hide_character_sw_png__WEBPACK_IMPORTED_MODULE_62___default.a,
  storyShowCharacter: _steps_story_show_character_sw_png__WEBPACK_IMPORTED_MODULE_63___default.a,
  // Video Sensing
  videoAddExtension: _steps_video_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_64___default.a,
  videoPet: _steps_video_pet_sw_png__WEBPACK_IMPORTED_MODULE_65___default.a,
  videoAnimate: _steps_video_animate_sw_png__WEBPACK_IMPORTED_MODULE_66___default.a,
  videoPop: _steps_video_pop_sw_png__WEBPACK_IMPORTED_MODULE_67___default.a,
  // Make it Fly
  flyChooseBackdrop: _steps_fly_choose_backdrop_LTR_gif__WEBPACK_IMPORTED_MODULE_68___default.a,
  flyChooseCharacter: _steps_fly_choose_character_LTR_png__WEBPACK_IMPORTED_MODULE_69___default.a,
  flySaySomething: _steps_fly_say_something_sw_png__WEBPACK_IMPORTED_MODULE_70___default.a,
  flyMoveArrows: _steps_fly_make_interactive_sw_png__WEBPACK_IMPORTED_MODULE_71___default.a,
  flyChooseObject: _steps_fly_object_to_collect_LTR_png__WEBPACK_IMPORTED_MODULE_72___default.a,
  flyFlyingObject: _steps_fly_flying_heart_sw_png__WEBPACK_IMPORTED_MODULE_73___default.a,
  flySelectFlyingSprite: _steps_fly_select_flyer_LTR_png__WEBPACK_IMPORTED_MODULE_74___default.a,
  flyAddScore: _steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  flyKeepScore: _steps_fly_keep_score_sw_png__WEBPACK_IMPORTED_MODULE_75___default.a,
  flyAddScenery: _steps_fly_choose_scenery_LTR_gif__WEBPACK_IMPORTED_MODULE_76___default.a,
  flyMoveScenery: _steps_fly_move_scenery_sw_png__WEBPACK_IMPORTED_MODULE_77___default.a,
  flySwitchLooks: _steps_fly_switch_costume_sw_png__WEBPACK_IMPORTED_MODULE_78___default.a,
  // Pong
  pongAddBackdrop: _steps_pong_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_79___default.a,
  pongAddBallSprite: _steps_pong_add_ball_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_80___default.a,
  pongBounceAround: _steps_pong_bounce_around_sw_png__WEBPACK_IMPORTED_MODULE_81___default.a,
  pongAddPaddle: _steps_pong_add_a_paddle_LTR_gif__WEBPACK_IMPORTED_MODULE_82___default.a,
  pongMoveThePaddle: _steps_pong_move_the_paddle_sw_png__WEBPACK_IMPORTED_MODULE_83___default.a,
  pongSelectBallSprite: _steps_pong_select_ball_LTR_png__WEBPACK_IMPORTED_MODULE_84___default.a,
  pongAddMoreCodeToBall: _steps_pong_add_code_to_ball_sw_png__WEBPACK_IMPORTED_MODULE_85___default.a,
  pongAddAScore: _steps_add_variable_sw_gif__WEBPACK_IMPORTED_MODULE_18___default.a,
  pongChooseScoreFromMenu: _steps_pong_choose_score_sw_png__WEBPACK_IMPORTED_MODULE_86___default.a,
  pongInsertChangeScoreBlock: _steps_pong_insert_change_score_sw_png__WEBPACK_IMPORTED_MODULE_87___default.a,
  pongResetScore: _steps_pong_reset_score_sw_png__WEBPACK_IMPORTED_MODULE_88___default.a,
  pongAddLineSprite: _steps_pong_add_line_LTR_gif__WEBPACK_IMPORTED_MODULE_89___default.a,
  pongGameOver: _steps_pong_game_over_sw_png__WEBPACK_IMPORTED_MODULE_90___default.a,
  // Imagine a World
  imagineTypeWhatYouWant: _steps_imagine_type_what_you_want_sw_png__WEBPACK_IMPORTED_MODULE_91___default.a,
  imagineClickGreenFlag: _steps_imagine_click_green_flag_sw_png__WEBPACK_IMPORTED_MODULE_92___default.a,
  imagineChooseBackdrop: _steps_imagine_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_93___default.a,
  imagineChooseSprite: _steps_imagine_choose_any_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_94___default.a,
  imagineFlyAround: _steps_imagine_fly_around_sw_png__WEBPACK_IMPORTED_MODULE_95___default.a,
  imagineChooseAnotherSprite: _steps_imagine_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_96___default.a,
  imagineLeftRight: _steps_imagine_left_right_sw_png__WEBPACK_IMPORTED_MODULE_97___default.a,
  imagineUpDown: _steps_imagine_up_down_sw_png__WEBPACK_IMPORTED_MODULE_98___default.a,
  imagineChangeCostumes: _steps_imagine_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_99___default.a,
  imagineGlideToPoint: _steps_imagine_glide_to_point_sw_png__WEBPACK_IMPORTED_MODULE_100___default.a,
  imagineGrowShrink: _steps_imagine_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_101___default.a,
  imagineChooseAnotherBackdrop: _steps_imagine_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_102___default.a,
  imagineSwitchBackdrops: _steps_imagine_switch_backdrops_sw_png__WEBPACK_IMPORTED_MODULE_103___default.a,
  imagineRecordASound: _steps_imagine_record_a_sound_sw_gif__WEBPACK_IMPORTED_MODULE_104___default.a,
  imagineChooseSound: _steps_imagine_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_105___default.a,
  // Add a Backdrop
  addBackdrop: _steps_add_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_106___default.a,
  // Add Effects
  addEffects: _steps_add_effects_sw_png__WEBPACK_IMPORTED_MODULE_107___default.a,
  // Hide and Show
  hideAndShow: _steps_hide_show_sw_png__WEBPACK_IMPORTED_MODULE_108___default.a,
  // Switch Costumes
  switchCostumes: _steps_switch_costumes_sw_png__WEBPACK_IMPORTED_MODULE_109___default.a,
  // Change Size
  changeSize: _steps_change_size_sw_png__WEBPACK_IMPORTED_MODULE_110___default.a,
  // Spin
  spinTurn: _steps_spin_turn_sw_png__WEBPACK_IMPORTED_MODULE_111___default.a,
  spinPointInDirection: _steps_spin_point_in_direction_sw_png__WEBPACK_IMPORTED_MODULE_112___default.a,
  // Record a Sound
  recordASoundSoundsTab: _steps_record_a_sound_sounds_tab_sw_png__WEBPACK_IMPORTED_MODULE_113___default.a,
  recordASoundClickRecord: _steps_record_a_sound_click_record_sw_png__WEBPACK_IMPORTED_MODULE_114___default.a,
  recordASoundPressRecordButton: _steps_record_a_sound_press_record_button_sw_png__WEBPACK_IMPORTED_MODULE_115___default.a,
  recordASoundChooseSound: _steps_record_a_sound_choose_sound_sw_png__WEBPACK_IMPORTED_MODULE_116___default.a,
  recordASoundPlayYourSound: _steps_record_a_sound_play_your_sound_sw_png__WEBPACK_IMPORTED_MODULE_117___default.a,
  // Use Arrow Keys
  moveArrowKeysLeftRight: _steps_move_arrow_keys_left_right_sw_png__WEBPACK_IMPORTED_MODULE_118___default.a,
  moveArrowKeysUpDown: _steps_move_arrow_keys_up_down_sw_png__WEBPACK_IMPORTED_MODULE_119___default.a,
  // Glide Around
  glideAroundBackAndForth: _steps_glide_around_back_and_forth_sw_png__WEBPACK_IMPORTED_MODULE_120___default.a,
  glideAroundPoint: _steps_glide_around_point_sw_png__WEBPACK_IMPORTED_MODULE_121___default.a,
  // Code a Cartoon
  codeCartoonSaySomething: _steps_code_cartoon_01_say_something_sw_png__WEBPACK_IMPORTED_MODULE_122___default.a,
  codeCartoonAnimate: _steps_code_cartoon_02_animate_sw_png__WEBPACK_IMPORTED_MODULE_123___default.a,
  codeCartoonSelectDifferentCharacter: _steps_code_cartoon_03_select_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_124___default.a,
  codeCartoonUseMinusSign: _steps_code_cartoon_04_use_minus_sign_sw_png__WEBPACK_IMPORTED_MODULE_125___default.a,
  codeCartoonGrowShrink: _steps_code_cartoon_05_grow_shrink_sw_png__WEBPACK_IMPORTED_MODULE_126___default.a,
  codeCartoonSelectDifferentCharacter2: _steps_code_cartoon_06_select_another_different_character_LTR_png__WEBPACK_IMPORTED_MODULE_127___default.a,
  codeCartoonJump: _steps_code_cartoon_07_jump_sw_png__WEBPACK_IMPORTED_MODULE_128___default.a,
  codeCartoonChangeScenes: _steps_code_cartoon_08_change_scenes_sw_png__WEBPACK_IMPORTED_MODULE_129___default.a,
  codeCartoonGlideAround: _steps_code_cartoon_09_glide_around_sw_png__WEBPACK_IMPORTED_MODULE_130___default.a,
  codeCartoonChangeCostumes: _steps_code_cartoon_10_change_costumes_sw_png__WEBPACK_IMPORTED_MODULE_131___default.a,
  codeCartoonChooseMoreCharacters: _steps_code_cartoon_11_choose_more_characters_LTR_png__WEBPACK_IMPORTED_MODULE_132___default.a,
  // Talking Tales
  talesAddExtension: _steps_speech_add_extension_sw_gif__WEBPACK_IMPORTED_MODULE_3___default.a,
  talesChooseSprite: _steps_talking_2_choose_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_133___default.a,
  talesSaySomething: _steps_talking_3_say_something_sw_png__WEBPACK_IMPORTED_MODULE_134___default.a,
  talesAskAnswer: _steps_talking_13_ask_and_answer_sw_png__WEBPACK_IMPORTED_MODULE_144___default.a,
  talesChooseBackdrop: _steps_talking_4_choose_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_135___default.a,
  talesSwitchBackdrop: _steps_talking_5_switch_backdrop_sw_png__WEBPACK_IMPORTED_MODULE_136___default.a,
  talesChooseAnotherSprite: _steps_talking_6_choose_another_sprite_LTR_png__WEBPACK_IMPORTED_MODULE_137___default.a,
  talesMoveAround: _steps_talking_7_move_around_sw_png__WEBPACK_IMPORTED_MODULE_138___default.a,
  talesChooseAnotherBackdrop: _steps_talking_8_choose_another_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_139___default.a,
  talesAnimateTalking: _steps_talking_9_animate_sw_png__WEBPACK_IMPORTED_MODULE_140___default.a,
  talesChooseThirdBackdrop: _steps_talking_10_choose_third_backdrop_LTR_png__WEBPACK_IMPORTED_MODULE_141___default.a,
  talesChooseSound: _steps_talking_11_choose_sound_sw_gif__WEBPACK_IMPORTED_MODULE_142___default.a,
  talesDanceMoves: _steps_talking_12_dance_moves_sw_png__WEBPACK_IMPORTED_MODULE_143___default.a
};


/***/ })

}]);